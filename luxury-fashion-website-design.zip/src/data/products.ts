export type Product = {
  id: string;
  name: string;
  brand: string;
  price: number;
  compareAt?: number;
  gender: "Men" | "Women" | "Unisex";
  collection: "Men" | "Women" | "Outdoor" | "Accessories";
  category: string;
  colors: string[];
  sizes: string[];
  rating: number;
  reviews: number;
  images: string[];
  badge?: string;
  isNew?: boolean;
  isBestSeller?: boolean;
  description: string;
};

const px = (id: number, w = 800, h = 1200) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=${w}&h=${h}`;

export const BRANDS = ["Maison Noir", "Atelier 21", "Nord & Co", "Éclat", "Verano"];
export const COLORS = [
  { name: "Black", hex: "#0a0a0a" },
  { name: "White", hex: "#f5f5f2" },
  { name: "Camel", hex: "#c19a6b" },
  { name: "Navy", hex: "#1e2a44" },
  { name: "Gold", hex: "#c9a84c" },
  { name: "Grey", hex: "#9ca3af" },
  { name: "Olive", hex: "#5b6236" },
  { name: "Burgundy", hex: "#5e1a2b" },
];
export const SIZES = ["XS", "S", "M", "L", "XL", "XXL"];

export const products: Product[] = [
  // WOMEN
  { id: "w1", name: "Silk Couture Gown", brand: "Maison Noir", price: 890, compareAt: 1200, gender: "Women", collection: "Women", category: "Dresses", colors: ["Burgundy", "Black"], sizes: ["XS", "S", "M", "L"], rating: 4.9, reviews: 214, images: [px(32628117), px(31046830), px(13638946)], badge: "Signature", isBestSeller: true, description: "An exquisitely draped couture gown crafted from mulberry silk, tailored for a sculptural silhouette that moves with quiet confidence." },
  { id: "w2", name: "Tailored Power Suit", brand: "Atelier 21", price: 640, gender: "Women", collection: "Women", category: "Jackets", colors: ["Burgundy", "Black", "Navy"], sizes: ["XS", "S", "M", "L", "XL"], rating: 4.8, reviews: 168, images: [px(38290945), px(38290951)], isNew: true, description: "A sharply tailored double-breasted suit that redefines modern power dressing with a fluid, feminine cut." },
  { id: "w3", name: "Organza Evening Dress", brand: "Éclat", price: 520, gender: "Women", collection: "Women", category: "Dresses", colors: ["White", "Grey"], sizes: ["XS", "S", "M"], rating: 4.7, reviews: 96, images: [px(13638946), px(17023685)], description: "Ethereal layers of organza create weightless movement for unforgettable evenings." },
  { id: "w4", name: "Shearling Statement Coat", brand: "Nord & Co", price: 1150, compareAt: 1450, gender: "Women", collection: "Women", category: "Jackets", colors: ["Camel", "Black"], sizes: ["S", "M", "L"], rating: 5.0, reviews: 141, images: [px(10356436), px(34121562), px(9690415)], badge: "Limited", isBestSeller: true, description: "A sumptuous shearling coat with an oversized collar — the definition of cold-weather luxury." },
  { id: "w5", name: "Midnight Slip Dress", brand: "Maison Noir", price: 380, gender: "Women", collection: "Women", category: "Dresses", colors: ["Black"], sizes: ["XS", "S", "M", "L"], rating: 4.6, reviews: 87, images: [px(14738813), px(19927157)], isNew: true, description: "A bias-cut slip dress in liquid satin that skims the body with effortless allure." },
  { id: "w6", name: "Atelier Striped Set", brand: "Verano", price: 295, gender: "Women", collection: "Women", category: "Tops", colors: ["White", "Navy"], sizes: ["XS", "S", "M", "L"], rating: 4.5, reviews: 63, images: [px(17238334), px(27383810)], description: "A refined two-piece set in breathable poplin, cut for a relaxed yet elevated daytime look." },
  { id: "w7", name: "Sculpted Blue Gown", brand: "Éclat", price: 610, gender: "Women", collection: "Women", category: "Dresses", colors: ["Navy"], sizes: ["XS", "S", "M", "L"], rating: 4.8, reviews: 112, images: [px(31046830), px(10909197)], description: "Architectural draping meets a rich cobalt tone for a truly commanding presence." },
  { id: "w8", name: "Emerald Column Dress", brand: "Atelier 21", price: 470, gender: "Women", collection: "Women", category: "Dresses", colors: ["Olive"], sizes: ["XS", "S", "M", "L"], rating: 4.7, reviews: 74, images: [px(19881909), px(19881903)], description: "A floor-grazing column dress in emerald crepe — understated glamour at its finest." },

  // MEN
  { id: "m1", name: "Monochrome Wool Suit", brand: "Maison Noir", price: 980, compareAt: 1250, gender: "Men", collection: "Men", category: "Suits", colors: ["Black", "Grey"], sizes: ["S", "M", "L", "XL", "XXL"], rating: 4.9, reviews: 302, images: [px(28938768), px(4611673), px(26524770)], badge: "Signature", isBestSeller: true, description: "A precision-cut wool suit with a contemporary slim silhouette, crafted in our Italian atelier." },
  { id: "m2", name: "Crimson Dinner Jacket", brand: "Atelier 21", price: 720, gender: "Men", collection: "Men", category: "Blazers", colors: ["Burgundy"], sizes: ["S", "M", "L", "XL"], rating: 4.8, reviews: 158, images: [px(7301566), px(30522893)], isNew: true, description: "Make an entrance in this velvet-touch crimson dinner jacket, tailored for evening occasions." },
  { id: "m3", name: "Executive Black Blazer", brand: "Nord & Co", price: 540, gender: "Men", collection: "Men", category: "Blazers", colors: ["Black"], sizes: ["S", "M", "L", "XL", "XXL"], rating: 4.7, reviews: 121, images: [px(6429760), px(26524770)], description: "A versatile single-breasted blazer that transitions seamlessly from boardroom to evening." },
  { id: "m4", name: "Charcoal Formal Suit", brand: "Maison Noir", price: 860, gender: "Men", collection: "Men", category: "Suits", colors: ["Grey", "Navy"], sizes: ["S", "M", "L", "XL"], rating: 4.9, reviews: 197, images: [px(30522893), px(33048697)], isBestSeller: true, description: "Timeless charcoal tailoring with a modern half-canvas construction for an impeccable drape." },
  { id: "m5", name: "Heritage Tuxedo", brand: "Éclat", price: 1290, compareAt: 1600, gender: "Men", collection: "Men", category: "Suits", colors: ["Black"], sizes: ["S", "M", "L", "XL"], rating: 5.0, reviews: 88, images: [px(17050922), px(4611661)], badge: "Limited", description: "A satin-lapel tuxedo engineered for the most distinguished black-tie affairs." },
  { id: "m6", name: "Slate Business Suit", brand: "Atelier 21", price: 690, gender: "Men", collection: "Men", category: "Suits", colors: ["Grey"], sizes: ["S", "M", "L", "XL", "XXL"], rating: 4.6, reviews: 143, images: [px(33048697), px(28938768)], isNew: true, description: "A refined slate-grey suit in a breathable four-season wool blend." },
  { id: "m7", name: "Tailored Twin Set", brand: "Verano", price: 460, gender: "Men", collection: "Men", category: "Shirts", colors: ["Black", "White"], sizes: ["S", "M", "L", "XL"], rating: 4.5, reviews: 76, images: [px(4611661), px(4611673)], description: "Coordinated shirt-and-jacket styling for the modern gentleman who values ease." },

  // OUTDOOR
  { id: "o1", name: "Alpine Down Parka", brand: "Nord & Co", price: 580, compareAt: 720, gender: "Men", collection: "Outdoor", category: "Winter Jackets", colors: ["Black", "Olive"], sizes: ["S", "M", "L", "XL", "XXL"], rating: 4.8, reviews: 234, images: [px(32532709), px(35631081)], badge: "Best Seller", isBestSeller: true, description: "A responsibly-sourced down parka rated for extreme cold without sacrificing a refined line." },
  { id: "o2", name: "Summit Trek Jacket", brand: "Verano", price: 340, gender: "Men", collection: "Outdoor", category: "Hiking Jackets", colors: ["Burgundy", "Grey"], sizes: ["S", "M", "L", "XL"], rating: 4.7, reviews: 189, images: [px(7009492), px(7009605)], isNew: true, description: "A technical hiking shell with sealed seams and four-way stretch for the trail." },
  { id: "o3", name: "Vermilion Ski Shell", brand: "Nord & Co", price: 420, gender: "Men", collection: "Outdoor", category: "Sports Wear", colors: ["Burgundy"], sizes: ["S", "M", "L", "XL"], rating: 4.6, reviews: 97, images: [px(7009605), px(7009492)], description: "High-visibility performance shell with an insulated core for the slopes." },
  { id: "o4", name: "Scarlet Field Jacket", brand: "Éclat", price: 380, gender: "Women", collection: "Outdoor", category: "Rain Coats", colors: ["Burgundy"], sizes: ["XS", "S", "M", "L"], rating: 4.7, reviews: 122, images: [px(9286276), px(9286283)], isNew: true, description: "A weather-ready field jacket that pairs urban polish with all-terrain protection." },
  { id: "o5", name: "Woodland Puffer", brand: "Verano", price: 310, gender: "Women", collection: "Outdoor", category: "Winter Jackets", colors: ["Olive", "Black"], sizes: ["XS", "S", "M", "L"], rating: 4.5, reviews: 84, images: [px(19869829), px(9286276)], description: "A lightweight yet warm puffer designed for crisp forest mornings." },
  { id: "o6", name: "Duo Trail Hoodie", brand: "Nord & Co", price: 190, gender: "Unisex", collection: "Outdoor", category: "Gym Wear", colors: ["Grey", "Burgundy"], sizes: ["S", "M", "L", "XL"], rating: 4.4, reviews: 66, images: [px(7010134), px(7009492)], description: "A cozy technical hoodie for base camp lounging and active layering alike." },

  // ACCESSORIES
  { id: "a1", name: "Nappa Leather Tote", brand: "Maison Noir", price: 490, compareAt: 640, gender: "Women", collection: "Accessories", category: "Bags", colors: ["Camel", "Black"], sizes: ["OS"], rating: 4.9, reviews: 176, images: [px(33471443), px(33471459)], badge: "Iconic", isBestSeller: true, description: "A structured tote in buttery nappa leather with signature gold hardware." },
  { id: "a2", name: "Gentleman's Edit Set", brand: "Atelier 21", price: 360, gender: "Men", collection: "Accessories", category: "Watches", colors: ["Black", "Gold"], sizes: ["OS"], rating: 4.8, reviews: 143, images: [px(37008332)], isNew: true, description: "A curated set of essentials — watch, shades and fragrance — for the discerning man." },
  { id: "a3", name: "Sunlit Aviators", brand: "Éclat", price: 220, gender: "Unisex", collection: "Accessories", category: "Sunglasses", colors: ["Gold", "Black"], sizes: ["OS"], rating: 4.7, reviews: 98, images: [px(33471463), px(33471459)], description: "Hand-polished acetate aviators with gradient lenses and gold detailing." },
  { id: "a4", name: "Atelier Accessory Trio", brand: "Verano", price: 280, gender: "Women", collection: "Accessories", category: "Bags", colors: ["Gold", "Camel"], sizes: ["OS"], rating: 4.6, reviews: 71, images: [px(31131955)], isNew: true, description: "A coordinated trio of fine accessories to complete any signature look." },
  { id: "a5", name: "Rive Gauche Perfume", brand: "Maison Noir", price: 160, gender: "Women", collection: "Accessories", category: "Perfumes", colors: ["Gold"], sizes: ["OS"], rating: 4.9, reviews: 265, images: [px(11678212), px(11678209)], isBestSeller: true, description: "An intoxicating eau de parfum layered with amber, jasmine and warm cedar." },
  { id: "a6", name: "Quilted Chain Purse", brand: "Éclat", price: 410, gender: "Women", collection: "Accessories", category: "Bags", colors: ["Burgundy", "Black"], sizes: ["OS"], rating: 4.7, reviews: 118, images: [px(4830930), px(33806932)], description: "A timeless quilted purse with a gold chain strap — day to night versatility." },
  { id: "a7", name: "Noir Fragrance & Pearls", brand: "Atelier 21", price: 340, gender: "Women", collection: "Accessories", category: "Jewelry", colors: ["Gold", "White"], sizes: ["OS"], rating: 4.8, reviews: 89, images: [px(11678209), px(11678212)], description: "A luxurious pairing of signature fragrance and freshwater pearl jewelry." },
  { id: "a8", name: "Everyday Luxe Wallet", brand: "Verano", price: 130, gender: "Unisex", collection: "Accessories", category: "Wallets", colors: ["Black", "Camel"], sizes: ["OS"], rating: 4.5, reviews: 54, images: [px(33806932), px(37008332)], description: "A slim leather wallet with meticulous edge-painting and RFID protection." },
];

export const collections = [
  { key: "Women", title: "Women", tagline: "Effortless Femininity", image: px(34121562, 900, 1200) },
  { key: "Men", title: "Men", tagline: "Tailored Precision", image: px(28938768, 900, 1200) },
  { key: "Outdoor", title: "Outdoor", tagline: "Engineered for Elements", image: px(32532709, 900, 1200) },
  { key: "Accessories", title: "Accessories", tagline: "The Finishing Touch", image: px(33471443, 900, 1200) },
];

export const categoryMenus: Record<string, string[]> = {
  Men: ["T-Shirts", "Polo Shirts", "Shirts", "Jeans", "Chinos", "Jackets", "Hoodies", "Blazers", "Suits", "Shoes", "Watches", "Accessories"],
  Women: ["Dresses", "Tops", "Jeans", "Skirts", "Hoodies", "Jackets", "Handbags", "Shoes", "Jewelry", "Perfumes"],
  Outdoor: ["Winter Jackets", "Hiking Jackets", "Rain Coats", "Sports Wear", "Gym Wear", "Running Shoes", "Outdoor Accessories"],
  Accessories: ["Watches", "Wallets", "Caps", "Sunglasses", "Belts", "Bags", "Perfumes"],
};

export function getProduct(id: string) {
  return products.find((p) => p.id === id);
}

export function relatedProducts(product: Product, limit = 4) {
  return products
    .filter((p) => p.id !== product.id && p.collection === product.collection)
    .slice(0, limit);
}
