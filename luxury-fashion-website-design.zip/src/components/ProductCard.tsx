import { Link } from "react-router-dom";
import { type Product } from "../data/products";
import { useShop } from "../context/ShopContext";
import { Icon, Stars, money } from "./ui";
import { cn } from "../utils/cn";

export default function ProductCard({ product, onQuickView }: { product: Product; onQuickView: (p: Product) => void }) {
  const { wishlist, toggleWishlist, compare, toggleCompare } = useShop();
  const wished = wishlist.includes(product.id);
  const compared = compare.includes(product.id);
  const discount = product.compareAt ? Math.round((1 - product.price / product.compareAt) * 100) : 0;

  return (
    <div className="group relative">
      <div className="relative overflow-hidden rounded-2xl bg-neutral-100 dark:bg-neutral-900">
        {/* badges */}
        <div className="absolute left-3 top-3 z-20 flex flex-col gap-1.5">
          {product.isNew && (
            <span className="rounded-full bg-ink px-3 py-1 text-[10px] font-medium uppercase tracking-[0.15em] text-white dark:bg-white dark:text-ink">New</span>
          )}
          {product.badge && (
            <span className="rounded-full bg-gold px-3 py-1 text-[10px] font-medium uppercase tracking-[0.15em] text-ink">{product.badge}</span>
          )}
          {discount > 0 && (
            <span className="rounded-full border border-ink/20 bg-white/80 px-3 py-1 text-[10px] font-medium uppercase tracking-[0.15em] text-ink">-{discount}%</span>
          )}
        </div>

        {/* action rail */}
        <div className="absolute right-3 top-3 z-20 flex flex-col gap-2 opacity-0 transition-all duration-500 group-hover:opacity-100">
          <IconBtn label="Wishlist" active={wished} onClick={() => toggleWishlist(product.id)}>
            <Icon.Heart className="h-4 w-4" fill={wished} />
          </IconBtn>
          <IconBtn label="Quick view" onClick={() => onQuickView(product)}>
            <Icon.Eye className="h-4 w-4" />
          </IconBtn>
          <IconBtn label="Compare" active={compared} onClick={() => toggleCompare(product.id)}>
            <Icon.Compare className="h-4 w-4" />
          </IconBtn>
        </div>

        <Link to={`/product/${product.id}`} className="block aspect-[3/4] w-full">
          <img
            src={product.images[0]}
            alt={product.name}
            loading="lazy"
            className="h-full w-full object-cover transition-all duration-[900ms] ease-out group-hover:scale-105"
          />
          {product.images[1] && (
            <img
              src={product.images[1]}
              alt={product.name}
              loading="lazy"
              className="absolute inset-0 h-full w-full object-cover opacity-0 transition-opacity duration-700 group-hover:opacity-100"
            />
          )}
        </Link>

        {/* quick add bar */}
        <button
          onClick={() => onQuickView(product)}
          className="absolute inset-x-3 bottom-3 z-20 translate-y-4 rounded-full bg-ink/90 py-3 text-[11px] font-medium uppercase tracking-[0.2em] text-white opacity-0 backdrop-blur transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100 hover:bg-gold hover:text-ink dark:bg-white/90 dark:text-ink"
        >
          Quick View
        </button>
      </div>

      <div className="mt-4 space-y-1">
        <div className="flex items-center justify-between">
          <span className="text-[10px] uppercase tracking-[0.2em] text-neutral-400">{product.brand}</span>
          <Stars rating={product.rating} />
        </div>
        <Link to={`/product/${product.id}`}>
          <h3 className="font-display text-base leading-snug transition-colors group-hover:text-gold">{product.name}</h3>
        </Link>
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">{money(product.price)}</span>
          {product.compareAt && <span className="text-xs text-neutral-400 line-through">{money(product.compareAt)}</span>}
        </div>
      </div>
    </div>
  );
}

function IconBtn({ children, label, onClick, active }: { children: React.ReactNode; label: string; onClick: () => void; active?: boolean }) {
  return (
    <button
      aria-label={label}
      onClick={onClick}
      className={cn(
        "flex h-9 w-9 items-center justify-center rounded-full border border-white/40 bg-white/80 text-ink shadow-sm backdrop-blur transition-all duration-300 hover:scale-110 hover:bg-gold hover:text-ink",
        active && "bg-gold text-ink"
      )}
    >
      {children}
    </button>
  );
}
