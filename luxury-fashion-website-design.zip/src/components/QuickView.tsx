import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { COLORS, type Product } from "../data/products";
import { useShop } from "../context/ShopContext";
import { Icon, Stars, GoldButton, money } from "./ui";
import { cn } from "../utils/cn";

export default function QuickView({ product, onClose }: { product: Product | null; onClose: () => void }) {
  const { addToCart, toggleWishlist, wishlist } = useShop();
  const [size, setSize] = useState("");
  const [color, setColor] = useState("");
  const [img, setImg] = useState(0);

  useEffect(() => {
    if (product) {
      setSize(product.sizes[0]);
      setColor(product.colors[0]);
      setImg(0);
      document.body.style.overflow = "hidden";
    }
    return () => { document.body.style.overflow = ""; };
  }, [product]);

  if (!product) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-ink/60 backdrop-blur-sm animate-[fade-up_0.3s_ease]" onClick={onClose} />
      <div className="relative z-10 grid max-h-[90vh] w-full max-w-4xl grid-cols-1 overflow-hidden rounded-3xl bg-white shadow-2xl dark:bg-neutral-900 md:grid-cols-2 animate-[fade-up_0.5s_cubic-bezier(0.16,1,0.3,1)]">
        <button onClick={onClose} className="absolute right-4 top-4 z-20 flex h-9 w-9 items-center justify-center rounded-full bg-white/80 text-ink backdrop-blur hover:bg-gold">
          <Icon.Close className="h-5 w-5" />
        </button>

        <div className="relative bg-neutral-100 dark:bg-neutral-800">
          <img src={product.images[img]} alt={product.name} className="aspect-[3/4] h-full w-full object-cover" />
          {product.images.length > 1 && (
            <div className="absolute bottom-3 left-1/2 flex -translate-x-1/2 gap-2">
              {product.images.map((_, i) => (
                <button key={i} onClick={() => setImg(i)} className={cn("h-1.5 w-6 rounded-full transition-all", i === img ? "bg-gold" : "bg-white/60")} />
              ))}
            </div>
          )}
        </div>

        <div className="overflow-y-auto p-7 md:p-9">
          <span className="text-[10px] uppercase tracking-[0.25em] text-neutral-400">{product.brand}</span>
          <h2 className="mt-1 font-display text-3xl">{product.name}</h2>
          <div className="mt-2 flex items-center gap-3">
            <Stars rating={product.rating} />
            <span className="text-xs text-neutral-400">{product.reviews} reviews</span>
          </div>
          <div className="mt-4 flex items-center gap-3">
            <span className="text-2xl font-medium">{money(product.price)}</span>
            {product.compareAt && <span className="text-neutral-400 line-through">{money(product.compareAt)}</span>}
          </div>
          <p className="mt-4 text-sm leading-relaxed text-neutral-500 dark:text-neutral-400">{product.description}</p>

          <div className="mt-6">
            <p className="mb-2 text-[11px] uppercase tracking-[0.2em] text-neutral-500">Colour — {color}</p>
            <div className="flex gap-2">
              {product.colors.map((c) => {
                const hex = COLORS.find((x) => x.name === c)?.hex ?? "#ccc";
                return (
                  <button key={c} onClick={() => setColor(c)} title={c}
                    className={cn("h-7 w-7 rounded-full border transition-all", color === c ? "ring-2 ring-gold ring-offset-2 dark:ring-offset-neutral-900" : "border-neutral-300")}
                    style={{ backgroundColor: hex }} />
                );
              })}
            </div>
          </div>

          <div className="mt-5">
            <p className="mb-2 text-[11px] uppercase tracking-[0.2em] text-neutral-500">Size</p>
            <div className="flex flex-wrap gap-2">
              {product.sizes.map((s) => (
                <button key={s} onClick={() => setSize(s)}
                  className={cn("min-w-11 rounded-full border px-3 py-2 text-xs transition-all", size === s ? "border-gold bg-gold text-ink" : "border-neutral-300 hover:border-gold dark:border-neutral-700")}>
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-7 flex items-center gap-3">
            <GoldButton className="flex-1" onClick={() => { addToCart(product.id, size, color); onClose(); }}>
              Add to Bag
            </GoldButton>
            <button onClick={() => toggleWishlist(product.id)}
              className="flex h-[52px] w-[52px] items-center justify-center rounded-full border border-neutral-300 hover:border-gold dark:border-neutral-700">
              <Icon.Heart className="h-5 w-5" fill={wishlist.includes(product.id)} />
            </button>
          </div>
          <Link to={`/product/${product.id}`} onClick={onClose} className="mt-4 inline-block text-xs uppercase tracking-[0.2em] text-gold link-underline">
            View full details →
          </Link>
        </div>
      </div>
    </div>
  );
}
