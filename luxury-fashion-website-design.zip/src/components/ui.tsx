import { useEffect, useRef, useState, type ReactNode } from "react";
import { cn } from "../utils/cn";

/* ---------------- Icons ---------------- */
type IconProps = { className?: string; strokeWidth?: number };
const S = ({ className, strokeWidth = 1.5, children }: IconProps & { children: ReactNode }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={strokeWidth}
    strokeLinecap="round" strokeLinejoin="round" className={className}>
    {children}
  </svg>
);

export const Icon = {
  Bag: (p: IconProps) => <S {...p}><path d="M6 7h12l1 13H5L6 7Z" /><path d="M9 7a3 3 0 0 1 6 0" /></S>,
  Heart: (p: IconProps & { fill?: boolean }) => (
    <svg viewBox="0 0 24 24" fill={p.fill ? "currentColor" : "none"} stroke="currentColor"
      strokeWidth={p.strokeWidth ?? 1.5} strokeLinecap="round" strokeLinejoin="round" className={p.className}>
      <path d="M12 20s-7-4.5-9.5-9A5 5 0 0 1 12 6a5 5 0 0 1 9.5 5c-2.5 4.5-9.5 9-9.5 9Z" />
    </svg>
  ),
  Search: (p: IconProps) => <S {...p}><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></S>,
  User: (p: IconProps) => <S {...p}><circle cx="12" cy="8" r="4" /><path d="M4 20a8 8 0 0 1 16 0" /></S>,
  Menu: (p: IconProps) => <S {...p}><path d="M3 6h18M3 12h18M3 18h18" /></S>,
  Close: (p: IconProps) => <S {...p}><path d="M6 6l12 12M18 6 6 18" /></S>,
  Sun: (p: IconProps) => <S {...p}><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4 12H2M22 12h-2M5 5l1.5 1.5M17.5 17.5 19 19M19 5l-1.5 1.5M6.5 17.5 5 19" /></S>,
  Moon: (p: IconProps) => <S {...p}><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z" /></S>,
  Chevron: (p: IconProps) => <S {...p}><path d="m6 9 6 6 6-6" /></S>,
  ArrowRight: (p: IconProps) => <S {...p}><path d="M5 12h14M13 6l6 6-6 6" /></S>,
  Star: (p: IconProps & { fill?: boolean }) => (
    <svg viewBox="0 0 24 24" fill={p.fill ? "currentColor" : "none"} stroke="currentColor"
      strokeWidth={p.strokeWidth ?? 1.2} strokeLinejoin="round" className={p.className}>
      <path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8L3.5 9.7l5.9-.9L12 3.5Z" />
    </svg>
  ),
  Eye: (p: IconProps) => <S {...p}><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z" /><circle cx="12" cy="12" r="3" /></S>,
  Compare: (p: IconProps) => <S {...p}><path d="M4 7h11M4 7l3-3M4 7l3 3M20 17H9M20 17l-3-3M20 17l-3 3" /></S>,
  Truck: (p: IconProps) => <S {...p}><path d="M3 6h11v9H3zM14 9h4l3 3v3h-7" /><circle cx="7" cy="18" r="1.6" /><circle cx="17" cy="18" r="1.6" /></S>,
  Shield: (p: IconProps) => <S {...p}><path d="M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6l7-3Z" /><path d="m9 12 2 2 4-4" /></S>,
  Leaf: (p: IconProps) => <S {...p}><path d="M11 20A7 7 0 0 1 4 13c0-6 7-9 15-9 0 8-3 15-9 15Z" /><path d="M4 20c3-6 6-8 10-9" /></S>,
  Gem: (p: IconProps) => <S {...p}><path d="M6 3h12l3 6-9 12L3 9l3-6Z" /><path d="M3 9h18M9 3l-3 6 6 12M15 3l3 6-6 12" /></S>,
  Plus: (p: IconProps) => <S {...p}><path d="M12 5v14M5 12h14" /></S>,
  Minus: (p: IconProps) => <S {...p}><path d="M5 12h14" /></S>,
  Check: (p: IconProps) => <S {...p}><path d="m5 12 5 5L20 6" /></S>,
  Mail: (p: IconProps) => <S {...p}><rect x="3" y="5" width="18" height="14" rx="2" /><path d="m3 7 9 6 9-6" /></S>,
  Phone: (p: IconProps) => <S {...p}><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L20 13l2 5v1a2 2 0 0 1-2 2A16 16 0 0 1 4 6a2 2 0 0 1 1-2Z" /></S>,
  Pin: (p: IconProps) => <S {...p}><path d="M12 21s7-5.5 7-11a7 7 0 1 0-14 0c0 5.5 7 11 7 11Z" /><circle cx="12" cy="10" r="2.5" /></S>,
  Chat: (p: IconProps) => <S {...p}><path d="M4 5h16v11H8l-4 4V5Z" /></S>,
  Insta: (p: IconProps) => <S {...p}><rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><circle cx="17" cy="7" r="1" /></S>,
  Trash: (p: IconProps) => <S {...p}><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13" /></S>,
  Sparkle: (p: IconProps) => <S {...p}><path d="M12 3v6M12 15v6M3 12h6M15 12h6M6 6l3 3M15 15l3 3M18 6l-3 3M9 15l-3 3" /></S>,
};

/* ---------------- Reveal on scroll ---------------- */
export function Reveal({ children, className, delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [vis, setVis] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setVis(true);
          io.disconnect();
        }
      },
      { threshold: 0.12 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} className={cn("reveal", vis && "is-visible", className)} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

/* ---------------- Stars ---------------- */
export function Stars({ rating, className }: { rating: number; className?: string }) {
  return (
    <div className={cn("flex items-center gap-0.5 text-gold", className)}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Icon.Star key={i} fill={i <= Math.round(rating)} className="h-3.5 w-3.5" />
      ))}
    </div>
  );
}

/* ---------------- Buttons ---------------- */
export function GoldButton({ children, className, ...rest }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...rest}
      className={cn(
        "group relative inline-flex items-center justify-center gap-2 overflow-hidden rounded-full bg-gold px-8 py-3.5 text-xs font-medium uppercase tracking-[0.18em] text-ink transition-all duration-300 hover:shadow-[0_10px_40px_-8px_rgba(201,168,76,0.7)] active:scale-[0.98]",
        className
      )}
    >
      <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/50 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
      <span className="relative z-10 flex items-center gap-2">{children}</span>
    </button>
  );
}

export function OutlineButton({ children, className, ...rest }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...rest}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-full border border-ink/25 px-8 py-3.5 text-xs font-medium uppercase tracking-[0.18em] text-ink transition-all duration-300 hover:border-gold hover:text-gold dark:border-white/25 dark:text-white",
        className
      )}
    >
      {children}
    </button>
  );
}

export const money = (n: number) => `$${n.toLocaleString("en-US")}`;
