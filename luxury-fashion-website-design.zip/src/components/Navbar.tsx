import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { categoryMenus, collections } from "../data/products";
import { useShop } from "../context/ShopContext";
import { useUI } from "../context/UIContext";
import { Icon } from "./ui";
import { cn } from "../utils/cn";

const NAV = [
  { label: "Women", to: "/collection/Women" },
  { label: "Men", to: "/collection/Men" },
  { label: "Outdoor", to: "/collection/Outdoor" },
  { label: "Accessories", to: "/collection/Accessories" },
  { label: "Shop", to: "/shop" },
  { label: "Blog", to: "/blog" },
  { label: "About", to: "/about" },
  { label: "Contact", to: "/contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [hover, setHover] = useState<string | null>(null);
  const [mobile, setMobile] = useState(false);
  const { cartCount, wishlist, dark, toggleDark } = useShop();
  const { setSearchOpen } = useUI();
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const megaKeys = ["Women", "Men", "Outdoor", "Accessories"];

  return (
    <>
      {/* Announcement bar */}
      <div className="bg-ink text-white">
        <div className="mx-auto flex max-w-[1400px] items-center justify-center gap-2 px-4 py-2 text-[10px] uppercase tracking-[0.25em] md:text-[11px]">
          <Icon.Sparkle className="h-3.5 w-3.5 text-gold" />
          Complimentary worldwide shipping over $250 · Signature gift packaging
        </div>
      </div>

      <header
        onMouseLeave={() => setHover(null)}
        className={cn(
          "sticky top-0 z-50 transition-all duration-500",
          scrolled ? "glass shadow-[0_8px_30px_-15px_rgba(0,0,0,0.3)]" : "bg-transparent"
        )}
      >
        <div className="mx-auto flex max-w-[1400px] items-center justify-between px-4 py-4 md:px-8">
          <button className="lg:hidden" onClick={() => setMobile(true)} aria-label="Menu">
            <Icon.Menu className="h-6 w-6" />
          </button>

          <Link to="/" className="flex flex-col items-center leading-none lg:items-start">
            <span className="font-display text-2xl font-semibold tracking-[0.15em]">MAISON</span>
            <span className="text-[10px] uppercase tracking-[0.55em] text-gold">Noir</span>
          </Link>

          <nav className="hidden items-center gap-7 lg:flex">
            {NAV.map((n) => (
              <div key={n.label} onMouseEnter={() => setHover(n.label)}>
                <Link
                  to={n.to}
                  className={cn(
                    "link-underline py-6 text-xs font-medium uppercase tracking-[0.18em] transition-colors",
                    hover === n.label ? "text-gold" : ""
                  )}
                >
                  {n.label}
                </Link>
              </div>
            ))}
          </nav>

          <div className="flex items-center gap-3 md:gap-4">
            <button aria-label="Search" onClick={() => setSearchOpen(true)} className="transition-colors hover:text-gold">
              <Icon.Search className="h-5 w-5" />
            </button>
            <button aria-label="Theme" onClick={toggleDark} className="transition-colors hover:text-gold">
              {dark ? <Icon.Sun className="h-5 w-5" /> : <Icon.Moon className="h-5 w-5" />}
            </button>
            <Link to="/account" aria-label="Account" className="hidden transition-colors hover:text-gold sm:block">
              <Icon.User className="h-5 w-5" />
            </Link>
            <Link to="/wishlist" aria-label="Wishlist" className="relative transition-colors hover:text-gold">
              <Icon.Heart className="h-5 w-5" />
              {wishlist.length > 0 && <Badge>{wishlist.length}</Badge>}
            </Link>
            <Link to="/cart" aria-label="Cart" className="relative transition-colors hover:text-gold">
              <Icon.Bag className="h-5 w-5" />
              {cartCount > 0 && <Badge>{cartCount}</Badge>}
            </Link>
          </div>
        </div>

        {/* Mega menu */}
        {megaKeys.includes(hover ?? "") && (
          <div className="absolute inset-x-0 top-full hidden lg:block">
            <div className="glass border-t border-black/5 shadow-xl">
              <div className="mx-auto grid max-w-[1400px] grid-cols-4 gap-8 px-8 py-9">
                <div className="col-span-3 grid grid-cols-3 gap-x-8 gap-y-2.5">
                  {categoryMenus[hover as string].map((c) => (
                    <button
                      key={c}
                      onClick={() => navigate(`/collection/${hover}?category=${encodeURIComponent(c)}`)}
                      className="group flex items-center justify-between py-1.5 text-left text-sm text-neutral-600 transition-colors hover:text-gold dark:text-neutral-300"
                    >
                      {c}
                      <Icon.ArrowRight className="h-3.5 w-3.5 -translate-x-2 opacity-0 transition-all group-hover:translate-x-0 group-hover:opacity-100" />
                    </button>
                  ))}
                </div>
                <Link to={`/collection/${hover}`} className="group relative overflow-hidden rounded-xl">
                  <img
                    src={collections.find((c) => c.key === hover)?.image}
                    alt={hover ?? ""}
                    className="h-56 w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-black/70 to-transparent p-5 text-white">
                    <p className="text-[10px] uppercase tracking-[0.25em] text-gold">Featured</p>
                    <p className="font-display text-xl">{hover} Edit</p>
                  </div>
                </Link>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Mobile drawer */}
      <div className={cn("fixed inset-0 z-[60] lg:hidden", mobile ? "pointer-events-auto" : "pointer-events-none")}>
        <div className={cn("absolute inset-0 bg-ink/50 transition-opacity", mobile ? "opacity-100" : "opacity-0")} onClick={() => setMobile(false)} />
        <div className={cn("absolute left-0 top-0 h-full w-80 max-w-[85%] bg-white p-6 shadow-2xl transition-transform duration-500 dark:bg-neutral-950", mobile ? "translate-x-0" : "-translate-x-full")}>
          <div className="mb-8 flex items-center justify-between">
            <span className="font-display text-xl tracking-[0.15em]">MAISON <span className="text-gold">NOIR</span></span>
            <button onClick={() => setMobile(false)}><Icon.Close className="h-6 w-6" /></button>
          </div>
          <nav className="flex flex-col">
            {NAV.map((n) => (
              <Link key={n.label} to={n.to} onClick={() => setMobile(false)}
                className="border-b border-black/5 py-3.5 font-display text-lg dark:border-white/10">
                {n.label}
              </Link>
            ))}
            <Link to="/account" onClick={() => setMobile(false)} className="border-b border-black/5 py-3.5 font-display text-lg dark:border-white/10">Account</Link>
          </nav>
        </div>
      </div>
    </>
  );
}

function Badge({ children }: { children: React.ReactNode }) {
  return (
    <span className="absolute -right-2 -top-2 flex h-4 min-w-4 items-center justify-center rounded-full bg-gold px-1 text-[9px] font-bold text-ink">
      {children}
    </span>
  );
}
