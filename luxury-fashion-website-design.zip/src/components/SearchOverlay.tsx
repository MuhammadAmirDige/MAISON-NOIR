import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { products } from "../data/products";
import { useUI } from "../context/UIContext";
import { Icon, money } from "./ui";

const suggestions = ["Silk gown", "Wool suit", "Leather tote", "Winter parka", "Perfume", "Tuxedo"];

export default function SearchOverlay() {
  const { searchOpen, setSearchOpen } = useUI();
  const [q, setQ] = useState("");

  useEffect(() => {
    if (searchOpen) {
      document.body.style.overflow = "hidden";
      setQ("");
    }
    return () => { document.body.style.overflow = ""; };
  }, [searchOpen]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setSearchOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setSearchOpen]);

  const results = useMemo(() => {
    if (!q.trim()) return [];
    const t = q.toLowerCase();
    return products
      .filter((p) => [p.name, p.brand, p.category, p.collection, p.description].join(" ").toLowerCase().includes(t))
      .slice(0, 6);
  }, [q]);

  if (!searchOpen) return null;

  return (
    <div className="fixed inset-0 z-[110]">
      <div className="absolute inset-0 bg-ink/70 backdrop-blur-md animate-[fade-up_0.3s_ease]" onClick={() => setSearchOpen(false)} />
      <div className="relative mx-auto mt-24 w-full max-w-2xl px-4 animate-[fade-up_0.5s_cubic-bezier(0.16,1,0.3,1)]">
        <div className="overflow-hidden rounded-2xl bg-white shadow-2xl dark:bg-neutral-900">
          <div className="flex items-center gap-3 border-b border-black/5 px-5 dark:border-white/10">
            <Icon.Sparkle className="h-5 w-5 text-gold" />
            <input
              autoFocus value={q} onChange={(e) => setQ(e.target.value)}
              placeholder="AI Search — try 'elegant black dress'"
              className="w-full bg-transparent py-5 text-lg focus:outline-none"
            />
            <button onClick={() => setSearchOpen(false)}><Icon.Close className="h-5 w-5" /></button>
          </div>

          <div className="max-h-[55vh] overflow-y-auto p-5">
            {!q && (
              <div>
                <p className="mb-3 text-[11px] uppercase tracking-[0.25em] text-neutral-400">Popular searches</p>
                <div className="flex flex-wrap gap-2">
                  {suggestions.map((s) => (
                    <button key={s} onClick={() => setQ(s)}
                      className="rounded-full border border-black/10 px-4 py-2 text-sm transition-colors hover:border-gold hover:text-gold dark:border-white/15">
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {q && results.length === 0 && (
              <p className="py-8 text-center text-sm text-neutral-400">No results for "{q}"</p>
            )}
            {results.map((p) => (
              <Link key={p.id} to={`/product/${p.id}`} onClick={() => setSearchOpen(false)}
                className="flex items-center gap-4 rounded-xl p-2 transition-colors hover:bg-neutral-100 dark:hover:bg-neutral-800">
                <img src={p.images[0]} alt={p.name} className="h-16 w-14 rounded-lg object-cover" />
                <div className="flex-1">
                  <p className="text-[10px] uppercase tracking-[0.2em] text-neutral-400">{p.brand}</p>
                  <p className="font-display">{p.name}</p>
                </div>
                <span className="text-sm font-medium">{money(p.price)}</span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
