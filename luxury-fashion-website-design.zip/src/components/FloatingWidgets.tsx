import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useShop } from "../context/ShopContext";
import { Icon } from "./ui";
import { cn } from "../utils/cn";

export default function FloatingWidgets() {
  const { toasts, compare } = useShop();
  const [top, setTop] = useState(false);
  const [chat, setChat] = useState(false);

  useEffect(() => {
    const onScroll = () => setTop(window.scrollY > 600);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      {/* Toasts */}
      <div className="fixed bottom-6 left-1/2 z-[200] flex -translate-x-1/2 flex-col items-center gap-2">
        {toasts.map((t) => (
          <div key={t.id} className="flex items-center gap-2 rounded-full bg-ink px-5 py-3 text-sm text-white shadow-xl animate-[fade-up_0.4s_ease] dark:bg-white dark:text-ink">
            <Icon.Check className="h-4 w-4 text-gold" /> {t.text}
          </div>
        ))}
      </div>

      {/* Compare bar */}
      {compare.length > 0 && (
        <Link to="/compare" className="fixed bottom-6 left-6 z-[120] flex items-center gap-2 rounded-full bg-ink px-5 py-3 text-sm text-white shadow-xl transition-transform hover:scale-105 dark:bg-white dark:text-ink">
          <Icon.Compare className="h-5 w-5 text-gold" /> Compare
          <span className="flex h-5 w-5 items-center justify-center rounded-full bg-gold text-[11px] font-bold text-ink">{compare.length}</span>
        </Link>
      )}

      {/* Right floating stack */}
      <div className="fixed bottom-6 right-6 z-[120] flex flex-col items-end gap-3">
        {chat && (
          <div className="w-72 overflow-hidden rounded-2xl bg-white shadow-2xl animate-[fade-up_0.4s_ease] dark:bg-neutral-900">
            <div className="flex items-center gap-2 bg-ink px-4 py-3 text-white">
              <span className="h-2 w-2 rounded-full bg-green-400" />
              <span className="text-sm font-medium">Maison Concierge</span>
            </div>
            <div className="space-y-2 p-4 text-sm">
              <p className="rounded-2xl rounded-tl-none bg-neutral-100 p-3 dark:bg-neutral-800">Welcome to Maison Noir. How may I assist you today?</p>
              <p className="text-right text-xs text-neutral-400">Typically replies in a minute</p>
            </div>
            <div className="border-t border-black/5 p-3 dark:border-white/10">
              <input placeholder="Type a message…" className="w-full rounded-full bg-neutral-100 px-4 py-2.5 text-sm focus:outline-none dark:bg-neutral-800" />
            </div>
          </div>
        )}

        <a href="https://wa.me/10000000000" target="_blank" rel="noreferrer"
          className="flex h-12 w-12 items-center justify-center rounded-full bg-green-500 text-white shadow-lg transition-transform hover:scale-110" aria-label="WhatsApp">
          <svg viewBox="0 0 24 24" fill="currentColor" className="h-6 w-6"><path d="M12 2a10 10 0 0 0-8.6 15l-1 3.6 3.7-1A10 10 0 1 0 12 2Zm5.3 14.1c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-4-4.7-4.2-.1-.2-1-1.4-1-2.6 0-1.2.6-1.8.9-2.1.2-.2.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 1.9c.1.2.1.4 0 .6l-.4.5c-.2.2-.3.4-.1.7.2.3.9 1.4 1.9 2.3 1.3 1.1 2.3 1.5 2.6 1.6.2.1.4.1.6-.1l.8-1c.2-.2.4-.2.6-.1l1.8.9c.3.1.5.2.5.3.1.1.1.5-.1 1.1Z" /></svg>
        </a>

        <button onClick={() => setChat((c) => !c)} aria-label="Live chat"
          className="flex h-12 w-12 items-center justify-center rounded-full bg-gold text-ink shadow-lg transition-transform hover:scale-110">
          {chat ? <Icon.Close className="h-5 w-5" /> : <Icon.Chat className="h-5 w-5" />}
        </button>

        <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="Back to top"
          className={cn("flex h-12 w-12 items-center justify-center rounded-full border border-ink/15 bg-white text-ink shadow-lg transition-all hover:border-gold dark:border-white/15 dark:bg-neutral-900 dark:text-white",
            top ? "scale-100 opacity-100" : "pointer-events-none scale-0 opacity-0")}>
          <Icon.Chevron className="h-5 w-5 rotate-180" />
        </button>
      </div>
    </>
  );
}
