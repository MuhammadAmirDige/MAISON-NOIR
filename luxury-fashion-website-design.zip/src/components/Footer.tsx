import { useState } from "react";
import { Link } from "react-router-dom";
import { Icon, money } from "./ui";

const cols = [
  { title: "Collections", links: [["Women", "/collection/Women"], ["Men", "/collection/Men"], ["Outdoor", "/collection/Outdoor"], ["Accessories", "/collection/Accessories"], ["New Arrivals", "/shop"]] },
  { title: "Quick Links", links: [["Shop All", "/shop"], ["Journal", "/blog"], ["About Us", "/about"], ["Contact", "/contact"], ["Track Order", "/account"]] },
  { title: "Customer Service", links: [["My Account", "/account"], ["Wishlist", "/wishlist"], ["Shipping Info", "/contact"], ["Returns", "/contact"], ["FAQs", "/contact"]] },
  { title: "Company", links: [["Privacy Policy", "/about"], ["Refund Policy", "/about"], ["Terms & Conditions", "/about"], ["Sustainability", "/about"], ["Careers", "/about"]] },
];

export default function Footer() {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);

  return (
    <footer className="mt-24 bg-ink text-neutral-300">
      {/* Newsletter */}
      <div className="border-b border-white/10">
        <div className="mx-auto grid max-w-[1400px] items-center gap-8 px-6 py-14 md:grid-cols-2 md:px-8">
          <div>
            <p className="text-[11px] uppercase tracking-[0.3em] text-gold">The Maison Circle</p>
            <h3 className="mt-3 font-display text-3xl text-white md:text-4xl">Join for private access & 10% off</h3>
            <p className="mt-2 max-w-md text-sm text-neutral-400">Be the first to receive new collection previews, invitations and members-only offers.</p>
          </div>
          <form
            onSubmit={(e) => { e.preventDefault(); if (email) { setDone(true); setEmail(""); } }}
            className="flex w-full max-w-md items-center gap-2 justify-self-start md:justify-self-end"
          >
            <div className="flex flex-1 items-center rounded-full border border-white/20 bg-white/5 px-5">
              <Icon.Mail className="h-5 w-5 text-neutral-400" />
              <input
                type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
                placeholder="Your email address"
                className="w-full bg-transparent px-3 py-3.5 text-sm text-white placeholder:text-neutral-500 focus:outline-none"
              />
            </div>
            <button className="rounded-full bg-gold px-6 py-3.5 text-xs font-medium uppercase tracking-[0.15em] text-ink transition-transform hover:scale-105">
              {done ? "Joined ✓" : "Subscribe"}
            </button>
          </form>
        </div>
      </div>

      {/* Links */}
      <div className="mx-auto grid max-w-[1400px] gap-10 px-6 py-16 md:grid-cols-5 md:px-8">
        <div className="md:col-span-1">
          <span className="font-display text-2xl tracking-[0.15em] text-white">MAISON</span>
          <p className="text-[10px] uppercase tracking-[0.5em] text-gold">Noir</p>
          <p className="mt-4 text-sm leading-relaxed text-neutral-400">
            An international house of timeless design, crafting elevated essentials since 1998.
          </p>
          <div className="mt-5 flex gap-3">
            {[Icon.Insta, Icon.Chat, Icon.Mail, Icon.Phone].map((I, i) => (
              <a key={i} href="#" className="flex h-9 w-9 items-center justify-center rounded-full border border-white/15 transition-all hover:border-gold hover:text-gold">
                <I className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>

        {cols.map((c) => (
          <div key={c.title}>
            <h4 className="mb-4 text-[11px] font-semibold uppercase tracking-[0.25em] text-white">{c.title}</h4>
            <ul className="space-y-2.5">
              {c.links.map(([label, to]) => (
                <li key={label}>
                  <Link to={to} className="text-sm text-neutral-400 transition-colors hover:text-gold">{label}</Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      {/* Bottom */}
      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-[1400px] flex-col items-center justify-between gap-4 px-6 py-6 text-xs text-neutral-500 md:flex-row md:px-8">
          <p>© {new Date().getFullYear()} Maison Noir. Crafted with intent. All rights reserved.</p>
          <div className="flex items-center gap-3 text-neutral-400">
            <span>We accept</span>
            {["VISA", "MC", "AMEX", "PAY"].map((p) => (
              <span key={p} className="rounded border border-white/15 px-2 py-1 text-[10px] tracking-wider">{p}</span>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}

export { money };
