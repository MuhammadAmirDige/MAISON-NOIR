import { useEffect } from "react";
import { Outlet, useLocation } from "react-router-dom";
import Navbar from "./Navbar";
import Footer from "./Footer";
import SearchOverlay from "./SearchOverlay";
import FloatingWidgets from "./FloatingWidgets";
import QuickView from "./QuickView";
import { useUI } from "../context/UIContext";

export default function Layout() {
  const { pathname } = useLocation();
  const { quickView, setQuickView } = useUI();

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [pathname]);

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
      <SearchOverlay />
      <FloatingWidgets />
      <QuickView product={quickView} onClose={() => setQuickView(null)} />
    </div>
  );
}
