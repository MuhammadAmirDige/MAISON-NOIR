import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { getProduct, type Product } from "../data/products";

export type CartItem = { id: string; size: string; color: string; qty: number };

type ToastMsg = { id: number; text: string };

type ShopState = {
  cart: CartItem[];
  wishlist: string[];
  compare: string[];
  recent: string[];
  dark: boolean;
  toasts: ToastMsg[];
  addToCart: (id: string, size: string, color: string, qty?: number) => void;
  removeFromCart: (index: number) => void;
  updateQty: (index: number, qty: number) => void;
  clearCart: () => void;
  toggleWishlist: (id: string) => void;
  toggleCompare: (id: string) => void;
  addRecent: (id: string) => void;
  toggleDark: () => void;
  toast: (text: string) => void;
  cartCount: number;
  cartTotal: number;
};

const ShopCtx = createContext<ShopState | null>(null);

function load<T>(key: string, fallback: T): T {
  try {
    const v = localStorage.getItem(key);
    return v ? (JSON.parse(v) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function ShopProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>(() => load("mn_cart", []));
  const [wishlist, setWishlist] = useState<string[]>(() => load("mn_wish", []));
  const [compare, setCompare] = useState<string[]>(() => load("mn_cmp", []));
  const [recent, setRecent] = useState<string[]>(() => load("mn_recent", []));
  const [dark, setDark] = useState<boolean>(() => load("mn_dark", false));
  const [toasts, setToasts] = useState<ToastMsg[]>([]);

  useEffect(() => localStorage.setItem("mn_cart", JSON.stringify(cart)), [cart]);
  useEffect(() => localStorage.setItem("mn_wish", JSON.stringify(wishlist)), [wishlist]);
  useEffect(() => localStorage.setItem("mn_cmp", JSON.stringify(compare)), [compare]);
  useEffect(() => localStorage.setItem("mn_recent", JSON.stringify(recent)), [recent]);
  useEffect(() => {
    localStorage.setItem("mn_dark", JSON.stringify(dark));
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  const toast = (text: string) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, text }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2600);
  };

  const addToCart: ShopState["addToCart"] = (id, size, color, qty = 1) => {
    setCart((c) => {
      const i = c.findIndex((x) => x.id === id && x.size === size && x.color === color);
      if (i >= 0) {
        const next = [...c];
        next[i] = { ...next[i], qty: next[i].qty + qty };
        return next;
      }
      return [...c, { id, size, color, qty }];
    });
    toast("Added to your bag");
  };

  const removeFromCart = (index: number) => setCart((c) => c.filter((_, i) => i !== index));
  const updateQty = (index: number, qty: number) =>
    setCart((c) => c.map((x, i) => (i === index ? { ...x, qty: Math.max(1, qty) } : x)));
  const clearCart = () => setCart([]);

  const toggleWishlist = (id: string) => {
    setWishlist((w) => {
      const has = w.includes(id);
      toast(has ? "Removed from wishlist" : "Saved to wishlist");
      return has ? w.filter((x) => x !== id) : [...w, id];
    });
  };

  const toggleCompare = (id: string) => {
    setCompare((c) => {
      if (c.includes(id)) return c.filter((x) => x !== id);
      if (c.length >= 4) {
        toast("Compare limit reached (4)");
        return c;
      }
      toast("Added to compare");
      return [...c, id];
    });
  };

  const addRecent = (id: string) => setRecent((r) => [id, ...r.filter((x) => x !== id)].slice(0, 8));
  const toggleDark = () => setDark((d) => !d);

  const cartCount = cart.reduce((s, x) => s + x.qty, 0);
  const cartTotal = cart.reduce((s, x) => {
    const p: Product | undefined = getProduct(x.id);
    return s + (p ? p.price * x.qty : 0);
  }, 0);

  const value = useMemo(
    () => ({
      cart, wishlist, compare, recent, dark, toasts,
      addToCart, removeFromCart, updateQty, clearCart,
      toggleWishlist, toggleCompare, addRecent, toggleDark, toast,
      cartCount, cartTotal,
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [cart, wishlist, compare, recent, dark, toasts]
  );

  return <ShopCtx.Provider value={value}>{children}</ShopCtx.Provider>;
}

export function useShop() {
  const ctx = useContext(ShopCtx);
  if (!ctx) throw new Error("useShop must be used within ShopProvider");
  return ctx;
}
