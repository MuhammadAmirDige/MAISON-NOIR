import { createContext, useContext, useState, type ReactNode } from "react";
import { type Product } from "../data/products";

type UIState = {
  quickView: Product | null;
  setQuickView: (p: Product | null) => void;
  searchOpen: boolean;
  setSearchOpen: (v: boolean) => void;
};

const UICtx = createContext<UIState | null>(null);

export function UIProvider({ children }: { children: ReactNode }) {
  const [quickView, setQuickView] = useState<Product | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  return (
    <UICtx.Provider value={{ quickView, setQuickView, searchOpen, setSearchOpen }}>
      {children}
    </UICtx.Provider>
  );
}

export function useUI() {
  const ctx = useContext(UICtx);
  if (!ctx) throw new Error("useUI must be used within UIProvider");
  return ctx;
}
