import { products } from "../data/products";
import { Reveal, Icon, OutlineButton } from "../components/ui";

const posts = [
  { cat: "Seasonal Trends", title: "The Return of Quiet Luxury", excerpt: "Why understated elegance is defining the wardrobes of the modern connoisseur this season.", read: "5 min", img: products[0].images[0] },
  { cat: "Style Tips", title: "Building a Timeless Capsule Wardrobe", excerpt: "Ten investment pieces that transcend trends and elevate every occasion.", read: "7 min", img: products[8].images[0] },
  { cat: "Buying Guides", title: "How to Choose the Perfect Wool Suit", excerpt: "A tailor's guide to fabric, fit and finish for a suit that lasts a lifetime.", read: "6 min", img: products[7].images[0] },
  { cat: "Fashion Articles", title: "The Art of Layering for Winter", excerpt: "Master the balance of warmth and silhouette with our expert styling notes.", read: "4 min", img: products[14].images[0] },
  { cat: "Style Tips", title: "Accessorising with Intention", excerpt: "The finishing touches that transform a look from ordinary to unforgettable.", read: "3 min", img: products[19].images[0] },
  { cat: "Seasonal Trends", title: "Colours That Define AW26", excerpt: "From deep burgundy to warm camel — the palette of the season decoded.", read: "5 min", img: products[3].images[0] },
];

export default function Blog() {
  const [feature, ...rest] = posts;
  return (
    <div className="mx-auto max-w-[1400px] px-6 py-12 md:px-8">
      <div className="mb-12 text-center">
        <p className="text-[11px] uppercase tracking-[0.3em] text-gold">The Maison Journal</p>
        <h1 className="mt-3 font-display text-5xl md:text-6xl">Style & Stories</h1>
        <p className="mx-auto mt-4 max-w-lg text-neutral-500">Fashion insights, seasonal trends and styling wisdom from the house of Maison Noir.</p>
      </div>

      {/* Feature */}
      <Reveal>
        <article className="group grid overflow-hidden rounded-3xl border border-black/5 md:grid-cols-2 dark:border-white/10">
          <div className="overflow-hidden">
            <img src={feature.img} alt={feature.title} className="h-full min-h-[320px] w-full object-cover transition-transform duration-[900ms] group-hover:scale-105" />
          </div>
          <div className="flex flex-col justify-center bg-cream p-8 md:p-12 dark:bg-neutral-900">
            <span className="text-[11px] uppercase tracking-[0.25em] text-gold">{feature.cat} · {feature.read}</span>
            <h2 className="mt-3 font-display text-3xl md:text-4xl">{feature.title}</h2>
            <p className="mt-4 text-neutral-600 dark:text-neutral-400">{feature.excerpt}</p>
            <button className="mt-6 inline-flex items-center gap-2 self-start text-xs uppercase tracking-[0.2em] text-gold link-underline">
              Read Article <Icon.ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </article>
      </Reveal>

      {/* Grid */}
      <div className="mt-10 grid gap-8 md:grid-cols-3">
        {rest.map((p, i) => (
          <Reveal key={p.title} delay={i * 80}>
            <article className="group cursor-pointer">
              <div className="overflow-hidden rounded-2xl">
                <img src={p.img} alt={p.title} className="aspect-[4/3] w-full object-cover transition-transform duration-[900ms] group-hover:scale-105" />
              </div>
              <span className="mt-4 block text-[11px] uppercase tracking-[0.25em] text-gold">{p.cat} · {p.read}</span>
              <h3 className="mt-2 font-display text-2xl transition-colors group-hover:text-gold">{p.title}</h3>
              <p className="mt-2 text-sm text-neutral-500">{p.excerpt}</p>
            </article>
          </Reveal>
        ))}
      </div>

      <div className="mt-14 text-center">
        <OutlineButton>Load More Articles</OutlineButton>
      </div>
    </div>
  );
}
