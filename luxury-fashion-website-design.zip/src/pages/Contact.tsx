import { useState } from "react";
import { Reveal, Icon, GoldButton } from "../components/ui";

const faqs = [
  ["What is your shipping timeframe?", "Standard delivery arrives within 3–5 business days, express within 1–2. Complimentary shipping applies to orders over $250."],
  ["Do you offer international delivery?", "Yes — we ship to 45 countries with carbon-neutral logistics and full tracking."],
  ["What is your returns policy?", "We accept returns within 30 days for unworn items in original condition. Returns are complimentary within your region."],
  ["How do I care for my garments?", "Each piece includes bespoke care instructions. Most items are dry clean only to preserve their finish."],
];

export default function Contact() {
  const [sent, setSent] = useState(false);
  const [open, setOpen] = useState<number | null>(0);
  const input = "w-full rounded-xl border border-neutral-300 bg-transparent px-4 py-3 text-sm focus:border-gold focus:outline-none dark:border-neutral-700";

  return (
    <div>
      <section className="bg-ink py-20 text-center text-white">
        <p className="text-[11px] uppercase tracking-[0.3em] text-gold">We're Here to Help</p>
        <h1 className="mt-3 font-display text-5xl md:text-6xl">Get in Touch</h1>
        <p className="mx-auto mt-4 max-w-lg px-6 text-neutral-300">Our client care team is available to assist with any enquiry, from styling advice to order support.</p>
      </section>

      <section className="mx-auto max-w-[1400px] px-6 py-16 md:px-8">
        <div className="grid gap-12 lg:grid-cols-2">
          {/* Form */}
          <Reveal>
            <h2 className="font-display text-3xl">Send a Message</h2>
            <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} className="mt-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <input required placeholder="First name" className={input} />
                <input required placeholder="Last name" className={input} />
              </div>
              <input required type="email" placeholder="Email address" className={input} />
              <input placeholder="Subject" className={input} />
              <textarea required rows={5} placeholder="Your message" className={input} />
              <GoldButton className="w-full">{sent ? "Message Sent ✓" : "Send Message"}</GoldButton>
              {sent && <p className="text-sm text-green-600">Thank you — we'll respond within 24 hours.</p>}
            </form>
          </Reveal>

          {/* Details */}
          <Reveal delay={120}>
            <h2 className="font-display text-3xl">Contact Details</h2>
            <div className="mt-6 space-y-4">
              {[
                [Icon.Pin, "Flagship Boutique", "Via Montenapoleone 12, Milan, Italy"],
                [Icon.Mail, "Email", "concierge@maisonnoir.com"],
                [Icon.Phone, "Phone", "+39 02 1234 5678"],
                [Icon.Chat, "Live Chat", "Available 24/7 via the chat widget"],
              ].map(([I, t, d], i) => {
                const Ic = I as any;
                return (
                  <div key={i} className="flex items-center gap-4 rounded-2xl border border-black/5 p-5 dark:border-white/10">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gold/15 text-gold"><Ic className="h-6 w-6" /></div>
                    <div><p className="text-[11px] uppercase tracking-[0.2em] text-neutral-400">{t as string}</p><p className="font-medium">{d as string}</p></div>
                  </div>
                );
              })}
              <div className="flex gap-3">
                <a href="https://wa.me/10000000000" target="_blank" rel="noreferrer" className="flex flex-1 items-center justify-center gap-2 rounded-full bg-green-500 py-3.5 text-sm font-medium text-white transition-transform hover:scale-[1.02]">
                  <Icon.Chat className="h-5 w-5" /> WhatsApp Us
                </a>
              </div>
            </div>

            <div className="mt-6 overflow-hidden rounded-2xl border border-black/5 dark:border-white/10">
              <iframe title="map" className="h-64 w-full grayscale" loading="lazy"
                src="https://www.openstreetmap.org/export/embed.html?bbox=9.18%2C45.46%2C9.21%2C45.48&layer=mapnik" />
            </div>
          </Reveal>
        </div>
      </section>

      {/* FAQ */}
      <section className="mx-auto max-w-3xl px-6 pb-24 md:px-8">
        <Reveal className="mb-10 text-center">
          <p className="text-[11px] uppercase tracking-[0.3em] text-gold">Need Answers?</p>
          <h2 className="mt-3 font-display text-4xl">Frequently Asked</h2>
        </Reveal>
        <div className="space-y-3">
          {faqs.map(([q, a], i) => (
            <div key={i} className="overflow-hidden rounded-2xl border border-black/5 dark:border-white/10">
              <button onClick={() => setOpen(open === i ? null : i)} className="flex w-full items-center justify-between p-5 text-left font-medium">
                {q}
                <Icon.Chevron className={`h-5 w-5 shrink-0 text-gold transition-transform ${open === i ? "rotate-180" : ""}`} />
              </button>
              <div className={`grid transition-all duration-300 ${open === i ? "grid-rows-[1fr]" : "grid-rows-[0fr]"}`}>
                <div className="overflow-hidden">
                  <p className="px-5 pb-5 text-sm text-neutral-500">{a}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
