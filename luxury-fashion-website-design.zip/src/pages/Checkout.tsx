import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { getProduct } from "../data/products";
import { useShop } from "../context/ShopContext";
import { Icon, GoldButton, money } from "../components/ui";
import { cn } from "../utils/cn";

export default function Checkout() {
  const { cart, cartTotal, clearCart } = useShop();
  const navigate = useNavigate();
  const [pay, setPay] = useState("card");
  const [sameAddr, setSameAddr] = useState(true);
  const [done, setDone] = useState(false);

  const shipping = cartTotal > 250 || cartTotal === 0 ? 0 : 25;
  const tax = Math.round(cartTotal * 0.08);
  const total = cartTotal + shipping + tax;

  if (done) {
    return (
      <div className="mx-auto max-w-xl px-6 py-32 text-center">
        <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-gold text-ink">
          <Icon.Check className="h-10 w-10" strokeWidth={2} />
        </div>
        <h1 className="mt-6 font-display text-4xl">Thank You</h1>
        <p className="mt-3 text-neutral-500">Your order has been confirmed. A confirmation email is on its way, and your pieces are being prepared with care.</p>
        <p className="mt-2 text-sm text-neutral-400">Order #MN{Math.floor(Math.random() * 900000 + 100000)}</p>
        <Link to="/shop" className="mt-8 inline-block"><GoldButton>Continue Shopping</GoldButton></Link>
      </div>
    );
  }

  if (cart.length === 0) {
    return (
      <div className="mx-auto max-w-xl px-6 py-32 text-center">
        <h1 className="font-display text-4xl">Your bag is empty</h1>
        <Link to="/shop" className="mt-6 inline-block"><GoldButton>Shop Now</GoldButton></Link>
      </div>
    );
  }

  const input = "w-full rounded-xl border border-neutral-300 bg-transparent px-4 py-3 text-sm focus:border-gold focus:outline-none dark:border-neutral-700";

  return (
    <div className="mx-auto max-w-[1400px] px-6 py-12 md:px-8">
      <h1 className="mb-2 font-display text-4xl md:text-5xl">Secure Checkout</h1>
      <p className="mb-10 flex items-center gap-2 text-sm text-neutral-500"><Icon.Shield className="h-4 w-4 text-gold" /> 256-bit SSL encrypted · Guest checkout available</p>

      <form onSubmit={(e) => { e.preventDefault(); setDone(true); clearCart(); }} className="grid gap-10 lg:grid-cols-[1fr_400px]">
        <div className="space-y-10">
          <Block title="Contact" step={1}>
            <input required type="email" placeholder="Email address" className={input} />
            <label className="flex items-center gap-2 text-sm text-neutral-500"><input type="checkbox" className="accent-[#c9a84c]" /> Email me with news and offers</label>
          </Block>

          <Block title="Shipping Address" step={2}>
            <div className="grid grid-cols-2 gap-3">
              <input required placeholder="First name" className={input} />
              <input required placeholder="Last name" className={input} />
            </div>
            <input required placeholder="Address" className={input} />
            <input placeholder="Apartment, suite (optional)" className={input} />
            <div className="grid grid-cols-3 gap-3">
              <input required placeholder="City" className={input} />
              <input required placeholder="Postal code" className={input} />
              <select className={input}>{["United States", "United Kingdom", "France", "Japan", "UAE"].map((c) => <option key={c}>{c}</option>)}</select>
            </div>
            <input required placeholder="Phone" className={input} />
            <label className="flex items-center gap-2 text-sm text-neutral-500">
              <input type="checkbox" checked={sameAddr} onChange={(e) => setSameAddr(e.target.checked)} className="accent-[#c9a84c]" /> Billing address same as shipping
            </label>
          </Block>

          {!sameAddr && (
            <Block title="Billing Address" step={3}>
              <input required placeholder="Address" className={input} />
              <div className="grid grid-cols-3 gap-3">
                <input required placeholder="City" className={input} />
                <input required placeholder="Postal code" className={input} />
                <input required placeholder="Country" className={input} />
              </div>
            </Block>
          )}

          <Block title="Payment Method" step={sameAddr ? 3 : 4}>
            <div className="grid grid-cols-3 gap-3">
              {[["card", "Card"], ["paypal", "PayPal"], ["apple", "Apple Pay"]].map(([v, l]) => (
                <button type="button" key={v} onClick={() => setPay(v)}
                  className={cn("rounded-xl border py-3 text-sm transition-all", pay === v ? "border-gold bg-gold/10 text-gold" : "border-neutral-300 dark:border-neutral-700")}>
                  {l}
                </button>
              ))}
            </div>
            {pay === "card" && (
              <div className="space-y-3">
                <input required placeholder="Card number" className={input} />
                <div className="grid grid-cols-2 gap-3">
                  <input required placeholder="MM / YY" className={input} />
                  <input required placeholder="CVC" className={input} />
                </div>
                <input required placeholder="Name on card" className={input} />
              </div>
            )}
            {pay !== "card" && <p className="rounded-xl bg-neutral-100 p-4 text-sm text-neutral-500 dark:bg-neutral-800">You'll be redirected to complete your payment securely.</p>}
          </Block>
        </div>

        {/* Summary */}
        <div className="h-fit space-y-4 rounded-2xl border border-black/5 bg-cream p-7 dark:border-white/10 dark:bg-neutral-900">
          <h2 className="font-display text-2xl">Your Order</h2>
          <div className="max-h-64 space-y-3 overflow-y-auto">
            {cart.map((item, i) => {
              const p = getProduct(item.id);
              if (!p) return null;
              return (
                <div key={i} className="flex items-center gap-3">
                  <div className="relative">
                    <img src={p.images[0]} alt={p.name} className="h-14 w-12 rounded-lg object-cover" />
                    <span className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-ink text-[10px] text-white dark:bg-white dark:text-ink">{item.qty}</span>
                  </div>
                  <div className="flex-1 text-sm">
                    <p className="font-medium leading-tight">{p.name}</p>
                    <p className="text-xs text-neutral-400">{item.color} · {item.size}</p>
                  </div>
                  <span className="text-sm">{money(p.price * item.qty)}</span>
                </div>
              );
            })}
          </div>
          <div className="space-y-2 border-t border-black/10 pt-4 text-sm dark:border-white/10">
            <Row label="Subtotal" value={money(cartTotal)} />
            <Row label="Shipping" value={shipping === 0 ? "Free" : money(shipping)} />
            <Row label="Tax" value={money(tax)} />
            <div className="flex justify-between border-t border-black/10 pt-3 text-lg font-medium dark:border-white/10">
              <span>Total</span><span className="text-gold">{money(total)}</span>
            </div>
          </div>
          <GoldButton className="w-full">Place Order — {money(total)}</GoldButton>
          <button type="button" onClick={() => navigate("/cart")} className="w-full text-center text-xs uppercase tracking-[0.2em] text-neutral-400 hover:text-gold">Return to Bag</button>
        </div>
      </form>
    </div>
  );
}

function Block({ title, step, children }: { title: string; step: number; children: React.ReactNode }) {
  return (
    <div>
      <h2 className="mb-4 flex items-center gap-3 font-display text-2xl">
        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-ink text-sm text-white dark:bg-white dark:text-ink">{step}</span>
        {title}
      </h2>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return <div className="flex justify-between text-neutral-600 dark:text-neutral-300"><span>{label}</span><span>{value}</span></div>;
}
