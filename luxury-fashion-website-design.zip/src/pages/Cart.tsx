import { useState } from "react";
import { Link } from "react-router-dom";
import { getProduct, products } from "../data/products";
import { useShop } from "../context/ShopContext";
import { useUI } from "../context/UIContext";
import ProductCard from "../components/ProductCard";
import { Icon, GoldButton, money } from "../components/ui";

export default function Cart() {
  const { cart, updateQty, removeFromCart, cartTotal } = useShop();
  const { setQuickView } = useUI();
  const [coupon, setCoupon] = useState("");
  const [applied, setApplied] = useState(0);
  const [country, setCountry] = useState("United States");

  const shipping = cartTotal > 250 || cartTotal === 0 ? 0 : 25;
  const discount = Math.round(cartTotal * applied);
  const total = cartTotal - discount + shipping;

  const apply = () => setApplied(coupon.trim().toUpperCase() === "MAISON10" ? 0.1 : 0);

  if (cart.length === 0) {
    return (
      <div className="mx-auto max-w-xl px-6 py-32 text-center">
        <Icon.Bag className="mx-auto h-16 w-16 text-neutral-300" />
        <h1 className="mt-6 font-display text-4xl">Your bag is empty</h1>
        <p className="mt-3 text-neutral-500">Discover timeless pieces crafted to be treasured.</p>
        <Link to="/shop" className="mt-8 inline-block"><GoldButton>Continue Shopping</GoldButton></Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-[1400px] px-6 py-12 md:px-8">
      <h1 className="mb-10 font-display text-4xl md:text-5xl">Shopping Bag</h1>
      <div className="grid gap-10 lg:grid-cols-[1fr_380px]">
        <div className="space-y-5">
          {cart.map((item, i) => {
            const p = getProduct(item.id);
            if (!p) return null;
            return (
              <div key={i} className="flex gap-4 rounded-2xl border border-black/5 p-4 dark:border-white/10">
                <Link to={`/product/${p.id}`} className="shrink-0">
                  <img src={p.images[0]} alt={p.name} className="h-32 w-24 rounded-xl object-cover" />
                </Link>
                <div className="flex flex-1 flex-col">
                  <div className="flex justify-between">
                    <div>
                      <p className="text-[10px] uppercase tracking-[0.2em] text-neutral-400">{p.brand}</p>
                      <Link to={`/product/${p.id}`} className="font-display text-lg hover:text-gold">{p.name}</Link>
                      <p className="mt-1 text-xs text-neutral-500">{item.color} · Size {item.size}</p>
                    </div>
                    <button onClick={() => removeFromCart(i)} className="text-neutral-400 transition-colors hover:text-red-500">
                      <Icon.Trash className="h-5 w-5" />
                    </button>
                  </div>
                  <div className="mt-auto flex items-center justify-between">
                    <div className="flex items-center rounded-full border border-neutral-300 dark:border-neutral-700">
                      <button onClick={() => updateQty(i, item.qty - 1)} className="px-3 py-2"><Icon.Minus className="h-3.5 w-3.5" /></button>
                      <span className="w-7 text-center text-sm">{item.qty}</span>
                      <button onClick={() => updateQty(i, item.qty + 1)} className="px-3 py-2"><Icon.Plus className="h-3.5 w-3.5" /></button>
                    </div>
                    <span className="font-medium">{money(p.price * item.qty)}</span>
                  </div>
                </div>
              </div>
            );
          })}
          <Link to="/shop" className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-gold link-underline">
            <Icon.ArrowRight className="h-4 w-4 rotate-180" /> Continue Shopping
          </Link>
        </div>

        {/* Summary */}
        <div className="h-fit space-y-5 rounded-2xl border border-black/5 bg-cream p-7 dark:border-white/10 dark:bg-neutral-900">
          <h2 className="font-display text-2xl">Order Summary</h2>

          <div>
            <p className="mb-2 text-[11px] uppercase tracking-[0.2em] text-neutral-500">Coupon Code</p>
            <div className="flex gap-2">
              <input value={coupon} onChange={(e) => setCoupon(e.target.value)} placeholder="Try MAISON10"
                className="flex-1 rounded-full border border-neutral-300 bg-transparent px-4 py-2.5 text-sm focus:border-gold focus:outline-none dark:border-neutral-700" />
              <button onClick={apply} className="rounded-full bg-ink px-5 py-2.5 text-xs uppercase tracking-[0.15em] text-white dark:bg-white dark:text-ink">Apply</button>
            </div>
            {applied > 0 && <p className="mt-2 text-xs text-green-600">✓ 10% discount applied</p>}
          </div>

          <div>
            <p className="mb-2 text-[11px] uppercase tracking-[0.2em] text-neutral-500">Shipping Estimate</p>
            <select value={country} onChange={(e) => setCountry(e.target.value)}
              className="w-full rounded-full border border-neutral-300 bg-transparent px-4 py-2.5 text-sm focus:border-gold focus:outline-none dark:border-neutral-700">
              {["United States", "United Kingdom", "France", "Japan", "UAE", "Australia"].map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>

          <div className="space-y-2.5 border-t border-black/10 pt-4 text-sm dark:border-white/10">
            <Row label="Subtotal" value={money(cartTotal)} />
            {discount > 0 && <Row label="Discount" value={`- ${money(discount)}`} />}
            <Row label="Shipping" value={shipping === 0 ? "Complimentary" : money(shipping)} />
            <div className="flex justify-between border-t border-black/10 pt-3 text-lg font-medium dark:border-white/10">
              <span>Total</span><span className="text-gold">{money(total)}</span>
            </div>
          </div>

          <Link to="/checkout" className="block"><GoldButton className="w-full">Proceed to Checkout</GoldButton></Link>
          <p className="text-center text-[11px] text-neutral-400">Secure encrypted payment · 30-day returns</p>
        </div>
      </div>

      {/* Recommended */}
      <div className="mt-20">
        <h2 className="mb-8 font-display text-3xl">You Might Also Like</h2>
        <div className="grid grid-cols-2 gap-x-4 gap-y-8 lg:grid-cols-4">
          {products.filter((p) => p.isBestSeller).slice(0, 4).map((p) => (
            <ProductCard key={p.id} product={p} onQuickView={setQuickView} />
          ))}
        </div>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return <div className="flex justify-between text-neutral-600 dark:text-neutral-300"><span>{label}</span><span>{value}</span></div>;
}
