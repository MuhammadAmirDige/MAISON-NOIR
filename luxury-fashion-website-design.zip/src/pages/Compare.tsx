import { Link } from "react-router-dom";
import { getProduct } from "../data/products";
import { useShop } from "../context/ShopContext";
import { Icon, GoldButton, Stars, money } from "../components/ui";

export default function Compare() {
  const { compare, toggleCompare, addToCart } = useShop();
  const items = compare.map((id) => getProduct(id)).filter(Boolean);

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-xl px-6 py-32 text-center">
        <Icon.Compare className="mx-auto h-16 w-16 text-neutral-300" />
        <h1 className="mt-6 font-display text-4xl">Nothing to compare yet</h1>
        <p className="mt-3 text-neutral-500">Add products to compare their details side by side.</p>
        <Link to="/shop" className="mt-8 inline-block"><GoldButton>Browse Products</GoldButton></Link>
      </div>
    );
  }

  const rows: [string, (p: any) => React.ReactNode][] = [
    ["Price", (p) => <span className="font-medium">{money(p.price)}</span>],
    ["Brand", (p) => p.brand],
    ["Rating", (p) => <Stars rating={p.rating} />],
    ["Collection", (p) => p.collection],
    ["Category", (p) => p.category],
    ["Colours", (p) => p.colors.join(", ")],
    ["Sizes", (p) => p.sizes.join(", ")],
  ];

  return (
    <div className="mx-auto max-w-[1400px] px-6 py-12 md:px-8">
      <h1 className="mb-10 text-center font-display text-5xl">Compare Products</h1>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] border-collapse">
          <thead>
            <tr>
              <th className="w-32" />
              {items.map((p) => (
                <th key={p!.id} className="p-3 align-top">
                  <div className="relative">
                    <button onClick={() => toggleCompare(p!.id)} className="absolute right-1 top-1 z-10 flex h-7 w-7 items-center justify-center rounded-full bg-white/80 text-ink backdrop-blur hover:bg-gold">
                      <Icon.Close className="h-4 w-4" />
                    </button>
                    <Link to={`/product/${p!.id}`}>
                      <img src={p!.images[0]} alt={p!.name} className="aspect-[3/4] w-full rounded-xl object-cover" />
                      <p className="mt-3 font-display text-lg">{p!.name}</p>
                    </Link>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map(([label, render]) => (
              <tr key={label} className="border-t border-black/5 dark:border-white/10">
                <td className="p-4 text-[11px] uppercase tracking-[0.15em] text-neutral-400">{label}</td>
                {items.map((p) => <td key={p!.id} className="p-4 text-center text-sm">{render(p)}</td>)}
              </tr>
            ))}
            <tr className="border-t border-black/5 dark:border-white/10">
              <td />
              {items.map((p) => (
                <td key={p!.id} className="p-4 text-center">
                  <GoldButton className="px-6 py-2.5" onClick={() => addToCart(p!.id, p!.sizes[0], p!.colors[0])}>Add to Bag</GoldButton>
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
