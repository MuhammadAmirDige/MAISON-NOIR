import { Link } from "react-router-dom";
import { getProduct } from "../data/products";
import { useShop } from "../context/ShopContext";
import { useUI } from "../context/UIContext";
import ProductCard from "../components/ProductCard";
import { Icon, GoldButton } from "../components/ui";

export default function Wishlist() {
  const { wishlist } = useShop();
  const { setQuickView } = useUI();
  const items = wishlist.map((id) => getProduct(id)).filter(Boolean);

  return (
    <div className="mx-auto max-w-[1400px] px-6 py-12 md:px-8">
      <div className="mb-10 text-center">
        <p className="text-[11px] uppercase tracking-[0.3em] text-gold">Saved For Later</p>
        <h1 className="mt-3 font-display text-5xl">My Wishlist</h1>
      </div>

      {items.length === 0 ? (
        <div className="py-24 text-center">
          <Icon.Heart className="mx-auto h-16 w-16 text-neutral-300" />
          <p className="mt-6 text-neutral-500">Your wishlist is empty. Save your favourite pieces here.</p>
          <Link to="/shop" className="mt-8 inline-block"><GoldButton>Explore Collection</GoldButton></Link>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-x-4 gap-y-8 lg:grid-cols-4">
          {items.map((p) => <ProductCard key={p!.id} product={p!} onQuickView={setQuickView} />)}
        </div>
      )}
    </div>
  );
}
