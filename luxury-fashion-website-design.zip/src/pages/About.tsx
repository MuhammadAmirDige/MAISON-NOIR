import { Link } from "react-router-dom";
import { Reveal, Icon, GoldButton } from "../components/ui";

export default function About() {
  return (
    <div>
      {/* Hero */}
      <section className="relative h-[70vh] min-h-[460px] overflow-hidden">
        <img src="/images/campaign.jpg" alt="Maison Noir atelier" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-ink/55" />
        <div className="relative flex h-full flex-col items-center justify-center px-6 text-center text-white">
          <p className="text-[11px] uppercase tracking-[0.4em] text-gold">Est. 1998 · Milan</p>
          <h1 className="mt-4 max-w-3xl font-display text-5xl leading-tight md:text-7xl">A House Built on Timelessness</h1>
        </div>
      </section>

      {/* Story */}
      <section className="mx-auto max-w-4xl px-6 py-20 text-center md:px-8">
        <Reveal>
          <p className="text-[11px] uppercase tracking-[0.3em] text-gold">Our Story</p>
          <h2 className="mt-3 font-display text-4xl md:text-5xl">Where Heritage Meets Modernity</h2>
          <p className="mt-6 text-lg leading-relaxed text-neutral-600 dark:text-neutral-400">
            Founded in a small Milanese atelier, Maison Noir began with a singular belief — that true luxury is felt, not shouted. For over two decades, we have crafted garments that transcend seasons, blending old-world craftsmanship with a modern, minimalist sensibility. Every piece is a quiet promise of quality, integrity, and enduring style.
          </p>
        </Reveal>
      </section>

      {/* Mission / Vision / Philosophy */}
      <section className="mx-auto grid max-w-[1400px] gap-6 px-6 pb-8 md:grid-cols-3 md:px-8">
        {[
          { icon: Icon.Gem, t: "Our Mission", d: "To craft garments of uncompromising quality that empower confidence and last a lifetime." },
          { icon: Icon.Sparkle, t: "Our Vision", d: "To define the future of conscious luxury — where beauty and responsibility are inseparable." },
          { icon: Icon.Heart, t: "Our Philosophy", d: "Quiet luxury. Restraint as sophistication. The belief that less, done exquisitely, is always more." },
        ].map((c, i) => (
          <Reveal key={c.t} delay={i * 100}>
            <div className="h-full rounded-2xl border border-black/5 bg-cream p-8 dark:border-white/10 dark:bg-neutral-900">
              <c.icon className="h-8 w-8 text-gold" />
              <h3 className="mt-4 font-display text-2xl">{c.t}</h3>
              <p className="mt-2 text-neutral-600 dark:text-neutral-400">{c.d}</p>
            </div>
          </Reveal>
        ))}
      </section>

      {/* Values banner */}
      <section className="bg-ink py-20 text-white">
        <div className="mx-auto max-w-[1400px] px-6 md:px-8">
          <div className="grid gap-12 md:grid-cols-2 md:items-center">
            <Reveal>
              <p className="text-[11px] uppercase tracking-[0.3em] text-gold">Sustainability & Quality</p>
              <h2 className="mt-3 font-display text-4xl leading-tight md:text-5xl">Conscious by Design</h2>
              <p className="mt-5 text-neutral-300">We believe luxury and responsibility go hand in hand. From regeneratively-farmed fibres to fully traceable supply chains and a lifetime repairs programme, every decision is made with the planet and future generations in mind.</p>
              <ul className="mt-6 space-y-3">
                {["100% traceable materials", "Carbon-neutral logistics", "Lifetime repairs & restoration", "Fair-wage artisan partners"].map((v) => (
                  <li key={v} className="flex items-center gap-3 text-neutral-200"><Icon.Check className="h-5 w-5 text-gold" /> {v}</li>
                ))}
              </ul>
            </Reveal>
            <Reveal delay={120}>
              <img src="/images/campaign.jpg" alt="Sustainable craftsmanship" className="rounded-2xl" />
            </Reveal>
          </div>
        </div>
      </section>

      {/* Journey timeline */}
      <section className="mx-auto max-w-4xl px-6 py-20 md:px-8">
        <Reveal className="mb-12 text-center">
          <p className="text-[11px] uppercase tracking-[0.3em] text-gold">The Journey</p>
          <h2 className="mt-3 font-display text-4xl md:text-5xl">Our Timeline</h2>
        </Reveal>
        <div className="space-y-8">
          {[
            ["1998", "The First Stitch", "Maison Noir opens its first atelier in Milan with a team of five master tailors."],
            ["2007", "Going Global", "Flagship boutiques open in Paris, London and Tokyo, introducing the house to the world."],
            ["2015", "The Conscious Turn", "We commit to full material traceability and launch our lifetime repairs programme."],
            ["2026", "A New Era", "Blending artisanal heritage with digital innovation for the modern connoisseur."],
          ].map(([year, t, d], i) => (
            <Reveal key={year as string} delay={i * 90}>
              <div className="flex gap-6">
                <div className="flex flex-col items-center">
                  <span className="font-display text-2xl text-gold">{year}</span>
                  <span className="mt-2 h-full w-px bg-gold/30" />
                </div>
                <div className="pb-2">
                  <h3 className="font-display text-xl">{t}</h3>
                  <p className="mt-1 text-neutral-600 dark:text-neutral-400">{d}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-6 pb-24 text-center md:px-8">
        <Reveal>
          <h2 className="font-display text-4xl">Experience the Collection</h2>
          <Link to="/shop" className="mt-6 inline-block"><GoldButton>Shop Now <Icon.ArrowRight className="h-4 w-4" /></GoldButton></Link>
        </Reveal>
      </section>
    </div>
  );
}
