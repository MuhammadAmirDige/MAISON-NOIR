import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { getProduct, relatedProducts, COLORS } from "../data/products";
import { useShop } from "../context/ShopContext";
import { useUI } from "../context/UIContext";
import ProductCard from "../components/ProductCard";
import { Icon, Stars, GoldButton, OutlineButton, Reveal, money } from "../components/ui";
import { cn } from "../utils/cn";

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const product = getProduct(id ?? "");
  const { addToCart, toggleWishlist, wishlist, toggleCompare, compare, recent, addRecent } = useShop();
  const { setQuickView } = useUI();

  const [img, setImg] = useState(0);
  const [size, setSize] = useState("");
  const [color, setColor] = useState("");
  const [qty, setQty] = useState(1);
  const [tab, setTab] = useState("Details");
  const [zoom, setZoom] = useState(false);
  const [pos, setPos] = useState({ x: 50, y: 50 });

  useEffect(() => {
    if (product) {
      setSize(product.sizes[0]);
      setColor(product.colors[0]);
      setImg(0);
      setQty(1);
      addRecent(product.id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (!product) {
    return (
      <div className="mx-auto max-w-xl px-6 py-40 text-center">
        <h1 className="font-display text-4xl">Piece not found</h1>
        <Link to="/shop" className="mt-6 inline-block"><GoldButton>Back to Shop</GoldButton></Link>
      </div>
    );
  }

  const related = relatedProducts(product);
  const recentItems = recent.map((r) => getProduct(r)).filter(Boolean).filter((p) => p!.id !== product.id).slice(0, 4);
  const wished = wishlist.includes(product.id);

  const tabs: Record<string, React.ReactNode> = {
    Details: <p className="leading-relaxed text-neutral-600 dark:text-neutral-400">{product.description} Crafted in limited quantities, this piece embodies the Maison Noir philosophy of quiet luxury — where restraint becomes the ultimate statement. Composition: 92% natural fibre, 8% elastane. Dry clean only.</p>,
    "Size Guide": (
      <table className="w-full text-sm">
        <thead><tr className="border-b border-black/10 text-left dark:border-white/10">{["Size", "Chest", "Waist", "Length"].map((h) => <th key={h} className="py-2 font-medium">{h}</th>)}</tr></thead>
        <tbody className="text-neutral-500">
          {[["XS", "34", "28", "26"], ["S", "36", "30", "27"], ["M", "38", "32", "28"], ["L", "40", "34", "29"], ["XL", "42", "36", "30"]].map((r) => (
            <tr key={r[0]} className="border-b border-black/5 dark:border-white/5">{r.map((c, i) => <td key={i} className="py-2.5">{c}{i > 0 ? '"' : ""}</td>)}</tr>
          ))}
        </tbody>
      </table>
    ),
    Shipping: <p className="leading-relaxed text-neutral-600 dark:text-neutral-400">Complimentary carbon-neutral express shipping on all orders over $250. Standard delivery arrives within 3–5 business days; express within 1–2. Each order ships in signature Maison Noir packaging with a hand-written note.</p>,
    Returns: <p className="leading-relaxed text-neutral-600 dark:text-neutral-400">We offer a 30-day return window for unworn items in original condition. Returns are complimentary within your region. Refunds are processed within 5 business days of receipt. Made-to-order pieces are final sale.</p>,
    Reviews: (
      <div className="space-y-5">
        {[{ n: "Amelia T.", t: "Absolutely stunning quality. Worth every penny.", r: 5 }, { n: "Marcus D.", t: "Fits perfectly and the fabric feels incredible.", r: 5 }, { n: "Chloé B.", t: "Elegant and timeless — I get compliments constantly.", r: 4 }].map((rv) => (
          <div key={rv.n} className="border-b border-black/5 pb-5 dark:border-white/5">
            <div className="flex items-center justify-between"><span className="font-medium">{rv.n}</span><Stars rating={rv.r} /></div>
            <p className="mt-2 text-sm text-neutral-500">{rv.t}</p>
          </div>
        ))}
      </div>
    ),
  };

  return (
    <div className="mx-auto max-w-[1400px] px-6 py-10 md:px-8">
      {/* Breadcrumb */}
      <div className="mb-8 flex items-center gap-2 text-xs uppercase tracking-[0.15em] text-neutral-400">
        <Link to="/" className="hover:text-gold">Home</Link><span>/</span>
        <Link to={`/collection/${product.collection}`} className="hover:text-gold">{product.collection}</Link><span>/</span>
        <span className="text-neutral-600 dark:text-neutral-300">{product.name}</span>
      </div>

      <div className="grid gap-10 lg:grid-cols-2">
        {/* Gallery */}
        <div className="flex gap-4">
          <div className="flex flex-col gap-3">
            {product.images.map((src, i) => (
              <button key={i} onClick={() => setImg(i)}
                className={cn("h-20 w-16 overflow-hidden rounded-lg border-2 transition-all", i === img ? "border-gold" : "border-transparent opacity-60 hover:opacity-100")}>
                <img src={src} alt="" className="h-full w-full object-cover" />
              </button>
            ))}
            <div className="flex h-20 w-16 items-center justify-center rounded-lg bg-ink text-white">
              <Icon.Eye className="h-5 w-5" />
            </div>
          </div>
          <div
            className="relative flex-1 overflow-hidden rounded-2xl bg-neutral-100 dark:bg-neutral-900"
            onMouseEnter={() => setZoom(true)} onMouseLeave={() => setZoom(false)}
            onMouseMove={(e) => {
              const r = e.currentTarget.getBoundingClientRect();
              setPos({ x: ((e.clientX - r.left) / r.width) * 100, y: ((e.clientY - r.top) / r.height) * 100 });
            }}
          >
            <img src={product.images[img]} alt={product.name}
              className="aspect-[3/4] w-full object-cover transition-transform duration-200"
              style={zoom ? { transform: "scale(1.9)", transformOrigin: `${pos.x}% ${pos.y}%` } : {}} />
            {product.badge && <span className="absolute left-4 top-4 rounded-full bg-gold px-3 py-1 text-[10px] font-medium uppercase tracking-[0.15em] text-ink">{product.badge}</span>}
            <span className="absolute bottom-4 right-4 rounded-full bg-white/70 px-3 py-1 text-[10px] uppercase tracking-[0.15em] text-ink backdrop-blur">Hover to zoom</span>
          </div>
        </div>

        {/* Info */}
        <div>
          <p className="text-[11px] uppercase tracking-[0.25em] text-neutral-400">{product.brand}</p>
          <h1 className="mt-2 font-display text-4xl md:text-5xl">{product.name}</h1>
          <div className="mt-3 flex items-center gap-3">
            <Stars rating={product.rating} />
            <span className="text-xs text-neutral-400">{product.rating} · {product.reviews} reviews</span>
          </div>
          <div className="mt-5 flex items-center gap-3">
            <span className="text-3xl font-medium">{money(product.price)}</span>
            {product.compareAt && <span className="text-lg text-neutral-400 line-through">{money(product.compareAt)}</span>}
            {product.compareAt && <span className="rounded-full bg-gold/15 px-3 py-1 text-xs font-medium text-gold">Save {money(product.compareAt - product.price)}</span>}
          </div>
          <p className="mt-5 leading-relaxed text-neutral-600 dark:text-neutral-400">{product.description}</p>

          <div className="mt-7">
            <p className="mb-2 text-[11px] uppercase tracking-[0.2em] text-neutral-500">Colour — {color}</p>
            <div className="flex gap-2.5">
              {product.colors.map((c) => {
                const hex = COLORS.find((x) => x.name === c)?.hex ?? "#ccc";
                return <button key={c} onClick={() => setColor(c)} title={c}
                  className={cn("h-9 w-9 rounded-full border transition-all", color === c ? "ring-2 ring-gold ring-offset-2 dark:ring-offset-neutral-950" : "border-neutral-300")}
                  style={{ backgroundColor: hex }} />;
              })}
            </div>
          </div>

          <div className="mt-6">
            <div className="mb-2 flex items-center justify-between">
              <p className="text-[11px] uppercase tracking-[0.2em] text-neutral-500">Size</p>
              <button onClick={() => setTab("Size Guide")} className="text-[11px] uppercase tracking-[0.15em] text-gold link-underline">Size Guide</button>
            </div>
            <div className="flex flex-wrap gap-2">
              {product.sizes.map((s) => (
                <button key={s} onClick={() => setSize(s)}
                  className={cn("min-w-12 rounded-full border px-4 py-2.5 text-sm transition-all", size === s ? "border-gold bg-gold text-ink" : "border-neutral-300 hover:border-gold dark:border-neutral-700")}>
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-7 flex items-center gap-4">
            <div className="flex items-center rounded-full border border-neutral-300 dark:border-neutral-700">
              <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="px-4 py-3"><Icon.Minus className="h-4 w-4" /></button>
              <span className="w-8 text-center text-sm font-medium">{qty}</span>
              <button onClick={() => setQty((q) => q + 1)} className="px-4 py-3"><Icon.Plus className="h-4 w-4" /></button>
            </div>
            <GoldButton className="flex-1" onClick={() => addToCart(product.id, size, color, qty)}>
              <Icon.Bag className="h-4 w-4" /> Add to Bag
            </GoldButton>
          </div>

          <div className="mt-3 flex gap-3">
            <OutlineButton className="flex-1" onClick={() => { addToCart(product.id, size, color, qty); navigate("/checkout"); }}>Buy Now</OutlineButton>
            <button onClick={() => toggleWishlist(product.id)} className={cn("flex h-[52px] w-[52px] items-center justify-center rounded-full border transition-colors", wished ? "border-gold text-gold" : "border-neutral-300 dark:border-neutral-700")}>
              <Icon.Heart className="h-5 w-5" fill={wished} />
            </button>
            <button onClick={() => toggleCompare(product.id)} className={cn("flex h-[52px] w-[52px] items-center justify-center rounded-full border transition-colors", compare.includes(product.id) ? "border-gold text-gold" : "border-neutral-300 dark:border-neutral-700")}>
              <Icon.Compare className="h-5 w-5" />
            </button>
          </div>

          <div className="mt-7 grid grid-cols-3 gap-3 text-center">
            {[[Icon.Truck, "Free Shipping"], [Icon.Shield, "2-Yr Warranty"], [Icon.Leaf, "Sustainable"]].map(([I, t], i) => {
              const Ic = I as any;
              return <div key={i} className="rounded-xl border border-black/5 p-3 dark:border-white/10">
                <Ic className="mx-auto h-6 w-6 text-gold" />
                <p className="mt-1.5 text-[11px] text-neutral-500">{t as string}</p>
              </div>;
            })}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="mt-16">
        <div className="flex flex-wrap gap-6 border-b border-black/10 dark:border-white/10">
          {Object.keys(tabs).map((t) => (
            <button key={t} onClick={() => setTab(t)}
              className={cn("relative pb-3 text-sm uppercase tracking-[0.15em] transition-colors", tab === t ? "text-gold" : "text-neutral-400 hover:text-neutral-600")}>
              {t}
              {tab === t && <span className="absolute inset-x-0 -bottom-px h-0.5 bg-gold" />}
            </button>
          ))}
        </div>
        <div className="max-w-3xl py-8">{tabs[tab]}</div>
      </div>

      {/* Related */}
      <div className="mt-8">
        <h2 className="mb-8 font-display text-3xl">You May Also Like</h2>
        <div className="grid grid-cols-2 gap-x-4 gap-y-8 lg:grid-cols-4">
          {related.map((p, i) => <Reveal key={p.id} delay={i * 70}><ProductCard product={p} onQuickView={setQuickView} /></Reveal>)}
        </div>
      </div>

      {recentItems.length > 0 && (
        <div className="mt-16">
          <h2 className="mb-8 font-display text-3xl">Recently Viewed</h2>
          <div className="grid grid-cols-2 gap-x-4 gap-y-8 lg:grid-cols-4">
            {recentItems.map((p) => <ProductCard key={p!.id} product={p!} onQuickView={setQuickView} />)}
          </div>
        </div>
      )}
    </div>
  );
}
