import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { products, collections } from "../data/products";
import { useUI } from "../context/UIContext";
import ProductCard from "../components/ProductCard";
import { Reveal, Icon, GoldButton, OutlineButton, Stars } from "../components/ui";
import { cn } from "../utils/cn";

function useCounter(target: number, run: boolean, dur = 1600) {
  const [v, setV] = useState(0);
  useEffect(() => {
    if (!run) return;
    let raf = 0;
    const start = performance.now();
    const tick = (t: number) => {
      const p = Math.min((t - start) / dur, 1);
      setV(Math.floor((1 - Math.pow(1 - p, 3)) * target));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [run, target, dur]);
  return v;
}

export default function Home() {
  const { setQuickView } = useUI();
  const newArrivals = products.filter((p) => p.isNew).slice(0, 4);
  const bestSellers = products.filter((p) => p.isBestSeller).slice(0, 4);
  const men = products.filter((p) => p.collection === "Men").slice(0, 4);
  const women = products.filter((p) => p.collection === "Women").slice(0, 4);

  return (
    <div>
      <Hero />
      <BrandMarquee />

      <Section title="Featured Collections" subtitle="Curated Edits" >
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {collections.map((c, i) => (
            <Reveal key={c.key} delay={i * 90}>
              <Link to={`/collection/${c.key}`} className="group relative block overflow-hidden rounded-2xl">
                <img src={c.image} alt={c.title} className="aspect-[3/4] w-full object-cover transition-transform duration-[900ms] group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-5 text-white">
                  <p className="text-[10px] uppercase tracking-[0.25em] text-gold">{c.tagline}</p>
                  <h3 className="font-display text-2xl">{c.title}</h3>
                  <span className="mt-1 inline-flex items-center gap-1 text-xs uppercase tracking-[0.15em] opacity-0 transition-all duration-500 group-hover:opacity-100">
                    Explore <Icon.ArrowRight className="h-3.5 w-3.5" />
                  </span>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </Section>

      <ProductRow title="New Arrivals" subtitle="Just Landed" items={newArrivals} onQuickView={setQuickView} link="/shop" />

      <CampaignBanner />

      <ProductRow title="Best Sellers" subtitle="Most Loved" items={bestSellers} onQuickView={setQuickView} link="/shop" tint />

      <SplitCollection title="Women's Collection" tagline="Effortless Femininity" items={women} image={collections[0].image} to="/collection/Women" onQuickView={setQuickView} />
      <SplitCollection title="Men's Collection" tagline="Tailored Precision" items={men} image={collections[1].image} to="/collection/Men" onQuickView={setQuickView} reverse />

      <WhyUs />
      <Counters />
      <Reviews />
      <Instagram />
    </div>
  );
}

function Hero() {
  return (
    <section className="relative h-[92vh] min-h-[600px] w-full overflow-hidden">
      <img src="/images/hero.jpg" alt="Maison Noir campaign" className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/30 to-black/10" />
      <div className="relative mx-auto flex h-full max-w-[1400px] flex-col justify-center px-6 md:px-10">
        <div className="max-w-2xl text-white">
          <p className="animate-[fade-up_0.8s_ease] text-[11px] uppercase tracking-[0.4em] text-gold">Autumn / Winter 2026</p>
          <h1 className="mt-4 font-display text-5xl leading-[1.02] md:text-7xl lg:text-8xl" style={{ animation: "fade-up 1s cubic-bezier(0.16,1,0.3,1) 0.1s both" }}>
            The Art of<br /><span className="text-gold-gradient italic">Quiet Luxury</span>
          </h1>
          <p className="mt-6 max-w-md text-base text-neutral-200 md:text-lg" style={{ animation: "fade-up 1s cubic-bezier(0.16,1,0.3,1) 0.25s both" }}>
            Timeless silhouettes crafted from the world's finest materials. Discover the collection redefining modern elegance.
          </p>
          <div className="mt-9 flex flex-wrap gap-4" style={{ animation: "fade-up 1s cubic-bezier(0.16,1,0.3,1) 0.4s both" }}>
            <Link to="/shop"><GoldButton>Shop The Collection <Icon.ArrowRight className="h-4 w-4" /></GoldButton></Link>
            <Link to="/collection/Women"><OutlineButton className="border-white/40 text-white hover:border-gold">Women's Edit</OutlineButton></Link>
          </div>
        </div>
      </div>
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/70">
        <div className="flex flex-col items-center gap-2 text-[10px] uppercase tracking-[0.3em]">
          Scroll
          <span className="h-10 w-px animate-pulse bg-white/40" />
        </div>
      </div>
    </section>
  );
}

function BrandMarquee() {
  const items = ["MAISON NOIR", "ATELIER 21", "NORD & CO", "ÉCLAT", "VERANO", "SINCE 1998"];
  return (
    <div className="border-y border-black/5 bg-white py-6 dark:border-white/10 dark:bg-neutral-950">
      <div className="flex overflow-hidden">
        <div className="flex shrink-0 animate-[marquee_28s_linear_infinite] items-center gap-16 pr-16">
          {[...items, ...items].map((t, i) => (
            <span key={i} className="font-display text-2xl tracking-[0.2em] text-neutral-300 dark:text-neutral-700">{t}</span>
          ))}
        </div>
        <div className="flex shrink-0 animate-[marquee_28s_linear_infinite] items-center gap-16 pr-16" aria-hidden>
          {[...items, ...items].map((t, i) => (
            <span key={i} className="font-display text-2xl tracking-[0.2em] text-neutral-300 dark:text-neutral-700">{t}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

export function Section({ title, subtitle, children, className }: { title: string; subtitle?: string; children: React.ReactNode; className?: string }) {
  return (
    <section className={cn("mx-auto max-w-[1400px] px-6 py-16 md:px-8 md:py-20", className)}>
      <Reveal className="mb-10 text-center">
        {subtitle && <p className="text-[11px] uppercase tracking-[0.3em] text-gold">{subtitle}</p>}
        <h2 className="mt-2 font-display text-4xl md:text-5xl">{title}</h2>
      </Reveal>
      {children}
    </section>
  );
}

function ProductRow({ title, subtitle, items, onQuickView, link, tint }: any) {
  return (
    <div className={cn(tint && "bg-white dark:bg-neutral-950")}>
      <Section title={title} subtitle={subtitle}>
        <div className="grid grid-cols-2 gap-x-4 gap-y-8 lg:grid-cols-4">
          {items.map((p: any, i: number) => (
            <Reveal key={p.id} delay={i * 80}><ProductCard product={p} onQuickView={onQuickView} /></Reveal>
          ))}
        </div>
        <div className="mt-12 text-center">
          <Link to={link}><OutlineButton>View All <Icon.ArrowRight className="h-4 w-4" /></OutlineButton></Link>
        </div>
      </Section>
    </div>
  );
}

function CampaignBanner() {
  return (
    <section className="relative my-8 overflow-hidden">
      <div className="mx-auto grid max-w-[1400px] items-stretch gap-0 px-0 md:grid-cols-2">
        <Reveal className="flex items-center bg-ink p-10 text-white md:p-16">
          <div>
            <p className="text-[11px] uppercase tracking-[0.3em] text-gold">The Winter Atelier</p>
            <h2 className="mt-4 font-display text-4xl leading-tight md:text-5xl">Crafted to Endure.<br />Designed to be Adored.</h2>
            <p className="mt-5 max-w-md text-neutral-300">Each piece passes through the hands of master artisans, ensuring uncompromising quality in every stitch.</p>
            <Link to="/about" className="mt-8 inline-block"><GoldButton>Our Craftsmanship</GoldButton></Link>
          </div>
        </Reveal>
        <Reveal delay={120} className="min-h-[400px]">
          <img src="/images/campaign.jpg" alt="Craftsmanship" className="h-full min-h-[400px] w-full object-cover" />
        </Reveal>
      </div>
    </section>
  );
}

function SplitCollection({ title, tagline, items, image, to, onQuickView, reverse }: any) {
  return (
    <Section title={title} subtitle={tagline}>
      <div className={cn("grid gap-6 lg:grid-cols-3", reverse && "")}>
        <Reveal className={cn("lg:col-span-1", reverse && "lg:order-last")}>
          <Link to={to} className="group relative block h-full overflow-hidden rounded-2xl">
            <img src={image} alt={title} className="h-full min-h-[420px] w-full object-cover transition-transform duration-[900ms] group-hover:scale-110" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 p-7 text-white">
              <h3 className="font-display text-3xl">{title}</h3>
              <span className="mt-2 inline-flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-gold">Shop Now <Icon.ArrowRight className="h-4 w-4" /></span>
            </div>
          </Link>
        </Reveal>
        <div className="grid grid-cols-2 gap-x-4 gap-y-8 lg:col-span-2">
          {items.map((p: any, i: number) => (
            <Reveal key={p.id} delay={i * 80}><ProductCard product={p} onQuickView={onQuickView} /></Reveal>
          ))}
        </div>
      </div>
    </Section>
  );
}

function WhyUs() {
  const feats = [
    { icon: Icon.Truck, title: "Global Express", text: "Complimentary carbon-neutral shipping on orders over $250 worldwide." },
    { icon: Icon.Shield, title: "Lifetime Assurance", text: "Every garment is backed by our craftsmanship guarantee and repairs." },
    { icon: Icon.Leaf, title: "Conscious Materials", text: "Responsibly sourced fibres and fully traceable supply chains." },
    { icon: Icon.Gem, title: "Artisan Made", text: "Hand-finished by master tailors in our European ateliers." },
  ];
  return (
    <section className="bg-ink py-20 text-white">
      <div className="mx-auto max-w-[1400px] px-6 md:px-8">
        <Reveal className="mb-14 text-center">
          <p className="text-[11px] uppercase tracking-[0.3em] text-gold">The Maison Standard</p>
          <h2 className="mt-2 font-display text-4xl md:text-5xl">Why Choose Us</h2>
        </Reveal>
        <div className="grid gap-8 md:grid-cols-4">
          {feats.map((f, i) => (
            <Reveal key={f.title} delay={i * 100} className="group text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-gold/40 text-gold transition-all duration-500 group-hover:bg-gold group-hover:text-ink">
                <f.icon className="h-7 w-7" />
              </div>
              <h3 className="mt-5 font-display text-xl">{f.title}</h3>
              <p className="mt-2 text-sm text-neutral-400">{f.text}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function Counters() {
  const ref = useRef<HTMLDivElement>(null);
  const [run, setRun] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => e.isIntersecting && (setRun(true), io.disconnect()), { threshold: 0.4 });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  const stats = [
    { n: 28, s: "+", l: "Years of Heritage" },
    { n: 120, s: "K", l: "Happy Clients" },
    { n: 45, s: "", l: "Countries Served" },
    { n: 98, s: "%", l: "Would Recommend" },
  ];
  return (
    <div ref={ref} className="mx-auto grid max-w-[1400px] grid-cols-2 gap-8 px-6 py-20 md:grid-cols-4 md:px-8">
      {stats.map((st) => (
        <StatItem key={st.l} n={st.n} s={st.s} l={st.l} run={run} />
      ))}
    </div>
  );
}

function StatItem({ n, s, l, run }: { n: number; s: string; l: string; run: boolean }) {
  const v = useCounter(n, run);
  return (
    <div className="text-center">
      <p className="font-display text-5xl text-gold md:text-6xl">{v}{s}</p>
      <p className="mt-2 text-xs uppercase tracking-[0.25em] text-neutral-500">{l}</p>
    </div>
  );
}

function Reviews() {
  const revs = [
    { name: "Isabella R.", role: "Milan", text: "The tailoring is impeccable — it fits like it was made for me. Nothing else compares.", rating: 5 },
    { name: "Julian M.", role: "London", text: "Investment pieces that last. The quality justifies every penny and then some.", rating: 5 },
    { name: "Sofia L.", role: "Paris", text: "From packaging to product, the experience feels genuinely luxurious. My new favourite house.", rating: 5 },
  ];
  return (
    <section className="bg-white py-20 dark:bg-neutral-950">
      <div className="mx-auto max-w-[1400px] px-6 md:px-8">
        <Reveal className="mb-14 text-center">
          <p className="text-[11px] uppercase tracking-[0.3em] text-gold">Words From Our Clients</p>
          <h2 className="mt-2 font-display text-4xl md:text-5xl">Customer Reviews</h2>
        </Reveal>
        <div className="grid gap-6 md:grid-cols-3">
          {revs.map((r, i) => (
            <Reveal key={r.name} delay={i * 100}>
              <div className="h-full rounded-2xl border border-black/5 bg-cream p-8 shadow-sm transition-shadow hover:shadow-xl dark:border-white/10 dark:bg-neutral-900">
                <Stars rating={r.rating} className="mb-4" />
                <p className="font-display text-lg italic leading-relaxed">"{r.text}"</p>
                <div className="mt-6 flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-full bg-gold font-display text-ink">{r.name[0]}</div>
                  <div>
                    <p className="text-sm font-medium">{r.name}</p>
                    <p className="text-xs text-neutral-400">{r.role}</p>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function Instagram() {
  const imgs = products.slice(0, 6).map((p) => p.images[0]);
  return (
    <Section title="@maisonnoir" subtitle="Follow The Journal">
      <div className="grid grid-cols-3 gap-2 md:grid-cols-6">
        {imgs.map((src, i) => (
          <Reveal key={i} delay={i * 60}>
            <a href="#" className="group relative block aspect-square overflow-hidden rounded-xl">
              <img src={src} alt="Instagram" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" />
              <div className="absolute inset-0 flex items-center justify-center bg-ink/0 text-white opacity-0 transition-all duration-500 group-hover:bg-ink/40 group-hover:opacity-100">
                <Icon.Insta className="h-7 w-7" />
              </div>
            </a>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}
