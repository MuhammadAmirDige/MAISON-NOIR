import { useState } from "react";
import { Link } from "react-router-dom";
import { getProduct } from "../data/products";
import { useShop } from "../context/ShopContext";
import { Icon, GoldButton, money } from "../components/ui";
import { cn } from "../utils/cn";

export default function Account() {
  const [authed, setAuthed] = useState(false);
  const [mode, setMode] = useState<"login" | "register">("login");
  const { wishlist } = useShop();
  const [tab, setTab] = useState("Overview");

  const input = "w-full rounded-xl border border-neutral-300 bg-transparent px-4 py-3 text-sm focus:border-gold focus:outline-none dark:border-neutral-700";

  if (!authed) {
    return (
      <div className="mx-auto max-w-md px-6 py-20">
        <div className="rounded-3xl border border-black/5 bg-cream p-8 dark:border-white/10 dark:bg-neutral-900">
          <div className="mb-6 flex rounded-full bg-black/5 p-1 dark:bg-white/5">
            {(["login", "register"] as const).map((m) => (
              <button key={m} onClick={() => setMode(m)}
                className={cn("flex-1 rounded-full py-2.5 text-xs uppercase tracking-[0.15em] transition-all", mode === m ? "bg-gold text-ink" : "text-neutral-500")}>
                {m === "login" ? "Sign In" : "Register"}
              </button>
            ))}
          </div>
          <h1 className="font-display text-3xl">{mode === "login" ? "Welcome Back" : "Create Account"}</h1>
          <p className="mt-1 text-sm text-neutral-500">{mode === "login" ? "Sign in to access your account." : "Join the Maison Circle."}</p>
          <form onSubmit={(e) => { e.preventDefault(); setAuthed(true); }} className="mt-6 space-y-3">
            {mode === "register" && <input required placeholder="Full name" className={input} />}
            <input required type="email" placeholder="Email address" className={input} />
            <input required type="password" placeholder="Password" className={input} />
            {mode === "login" && <button type="button" className="text-xs text-gold link-underline">Forgot password?</button>}
            <GoldButton className="w-full">{mode === "login" ? "Sign In" : "Create Account"}</GoldButton>
          </form>
          <p className="mt-5 text-center text-xs text-neutral-400">By continuing you agree to our Terms & Privacy Policy.</p>
        </div>
      </div>
    );
  }

  const orders = [
    { id: "MN802341", date: "12 Jan 2026", status: "Delivered", total: 1620, items: 2 },
    { id: "MN798115", date: "28 Dec 2025", status: "In Transit", total: 490, items: 1 },
    { id: "MN781902", date: "05 Dec 2025", status: "Delivered", total: 980, items: 1 },
  ];

  const tabs = ["Overview", "Orders", "Track Order", "Addresses", "Wishlist"];

  return (
    <div className="mx-auto max-w-[1400px] px-6 py-12 md:px-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="font-display text-4xl">My Account</h1>
          <p className="text-neutral-500">Welcome back, Alexandra</p>
        </div>
        <button onClick={() => setAuthed(false)} className="text-xs uppercase tracking-[0.2em] text-gold link-underline">Sign Out</button>
      </div>

      <div className="grid gap-8 lg:grid-cols-[240px_1fr]">
        <aside className="flex gap-2 overflow-x-auto lg:flex-col">
          {tabs.map((t) => (
            <button key={t} onClick={() => setTab(t)}
              className={cn("whitespace-nowrap rounded-xl px-4 py-3 text-left text-sm transition-all", tab === t ? "bg-gold text-ink" : "hover:bg-black/5 dark:hover:bg-white/5")}>
              {t}
            </button>
          ))}
        </aside>

        <div>
          {tab === "Overview" && (
            <div className="grid gap-4 sm:grid-cols-3">
              {[["Total Orders", "12"], ["Wishlist Items", String(wishlist.length)], ["Loyalty Points", "2,480"]].map(([l, v]) => (
                <div key={l} className="rounded-2xl border border-black/5 bg-cream p-6 dark:border-white/10 dark:bg-neutral-900">
                  <p className="text-[11px] uppercase tracking-[0.2em] text-neutral-400">{l}</p>
                  <p className="mt-2 font-display text-4xl text-gold">{v}</p>
                </div>
              ))}
            </div>
          )}

          {tab === "Orders" && (
            <div className="space-y-3">
              {orders.map((o) => (
                <div key={o.id} className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-black/5 p-5 dark:border-white/10">
                  <div><p className="font-medium">#{o.id}</p><p className="text-xs text-neutral-400">{o.date} · {o.items} item(s)</p></div>
                  <span className={cn("rounded-full px-3 py-1 text-xs", o.status === "Delivered" ? "bg-green-500/15 text-green-600" : "bg-gold/15 text-gold")}>{o.status}</span>
                  <span className="font-medium">{money(o.total)}</span>
                  <button className="text-xs uppercase tracking-[0.15em] text-gold link-underline">View</button>
                </div>
              ))}
            </div>
          )}

          {tab === "Track Order" && (
            <div className="max-w-lg">
              <p className="text-neutral-500">Enter your order number to see live status.</p>
              <div className="mt-4 flex gap-2">
                <input placeholder="e.g. MN798115" className={input} />
                <GoldButton>Track</GoldButton>
              </div>
              <div className="mt-8 space-y-6">
                {[["Order Placed", true], ["Processing", true], ["Shipped", true], ["Out for Delivery", false], ["Delivered", false]].map(([s, done], i) => (
                  <div key={i} className="flex items-center gap-4">
                    <span className={cn("flex h-8 w-8 items-center justify-center rounded-full", done ? "bg-gold text-ink" : "border border-neutral-300 text-neutral-400 dark:border-neutral-700")}>
                      {done ? <Icon.Check className="h-4 w-4" strokeWidth={3} /> : i + 1}
                    </span>
                    <span className={cn(done ? "font-medium" : "text-neutral-400")}>{s as string}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === "Addresses" && (
            <div className="grid gap-4 sm:grid-cols-2">
              {[["Home", "12 Via Montenapoleone, Milan, 20121, Italy"], ["Office", "45 Rue Saint-Honoré, Paris, 75001, France"]].map(([t, a]) => (
                <div key={t} className="rounded-2xl border border-black/5 p-6 dark:border-white/10">
                  <div className="flex items-center justify-between"><p className="font-medium">{t}</p><Icon.Pin className="h-5 w-5 text-gold" /></div>
                  <p className="mt-2 text-sm text-neutral-500">{a}</p>
                  <div className="mt-4 flex gap-3 text-xs uppercase tracking-[0.15em] text-gold"><button className="link-underline">Edit</button><button className="link-underline">Remove</button></div>
                </div>
              ))}
              <button className="flex min-h-32 items-center justify-center gap-2 rounded-2xl border border-dashed border-neutral-300 text-sm text-neutral-500 hover:border-gold hover:text-gold dark:border-neutral-700">
                <Icon.Plus className="h-5 w-5" /> Add New Address
              </button>
            </div>
          )}

          {tab === "Wishlist" && (
            wishlist.length === 0 ? (
              <p className="text-neutral-500">Your wishlist is empty. <Link to="/shop" className="text-gold link-underline">Discover pieces</Link></p>
            ) : (
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
                {wishlist.map((id) => { const p = getProduct(id); return p ? (
                  <Link key={id} to={`/product/${id}`} className="group">
                    <img src={p.images[0]} alt={p.name} className="aspect-[3/4] w-full rounded-xl object-cover" />
                    <p className="mt-2 font-display group-hover:text-gold">{p.name}</p>
                    <p className="text-sm text-neutral-500">{money(p.price)}</p>
                  </Link>
                ) : null; })}
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
}
