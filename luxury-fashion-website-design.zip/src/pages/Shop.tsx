import { useMemo, useState, useEffect } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { products, BRANDS, COLORS, SIZES, categoryMenus, collections } from "../data/products";
import { useUI } from "../context/UIContext";
import ProductCard from "../components/ProductCard";
import { Reveal, Icon } from "../components/ui";
import { cn } from "../utils/cn";

const PER_PAGE = 8;

export default function Shop() {
  const { key } = useParams();
  const [params, setParams] = useSearchParams();
  const { setQuickView } = useUI();

  const fixedCollection = key && ["Men", "Women", "Outdoor", "Accessories"].includes(key) ? key : null;
  const collectionMeta = collections.find((c) => c.key === fixedCollection);

  const [cats, setCats] = useState<string[]>(params.get("category") ? [params.get("category")!] : []);
  const [brands, setBrands] = useState<string[]>([]);
  const [cols, setCols] = useState<string[]>([]);
  const [sizes, setSizes] = useState<string[]>([]);
  const [maxPrice, setMaxPrice] = useState(1600);
  const [sort, setSort] = useState("featured");
  const [page, setPage] = useState(1);
  const [drawer, setDrawer] = useState(false);

  useEffect(() => {
    const c = params.get("category");
    setCats(c ? [c] : []);
    setPage(1);
  }, [key, params]);

  const availableCats = fixedCollection ? categoryMenus[fixedCollection] : [...new Set(products.map((p) => p.category))];

  const filtered = useMemo(() => {
    let list = products.slice();
    if (fixedCollection) list = list.filter((p) => p.collection === fixedCollection);
    if (cats.length) list = list.filter((p) => cats.includes(p.category));
    if (brands.length) list = list.filter((p) => brands.includes(p.brand));
    if (cols.length) list = list.filter((p) => p.colors.some((c) => cols.includes(c)));
    if (sizes.length) list = list.filter((p) => p.sizes.some((s) => sizes.includes(s)));
    list = list.filter((p) => p.price <= maxPrice);
    switch (sort) {
      case "low": list.sort((a, b) => a.price - b.price); break;
      case "high": list.sort((a, b) => b.price - a.price); break;
      case "rating": list.sort((a, b) => b.rating - a.rating); break;
      case "new": list.sort((a, b) => Number(b.isNew) - Number(a.isNew)); break;
    }
    return list;
  }, [fixedCollection, cats, brands, cols, sizes, maxPrice, sort]);

  const pages = Math.max(1, Math.ceil(filtered.length / PER_PAGE));
  const shown = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  const toggle = (arr: string[], set: (v: string[]) => void, val: string) => {
    set(arr.includes(val) ? arr.filter((x) => x !== val) : [...arr, val]);
    setPage(1);
  };

  const clearAll = () => { setCats([]); setBrands([]); setCols([]); setSizes([]); setMaxPrice(1600); setParams({}); setPage(1); };

  const Filters = (
    <div className="space-y-8">
      <FilterBlock title="Category">
        {availableCats.map((c) => (
          <Check key={c} label={c} checked={cats.includes(c)} onChange={() => toggle(cats, setCats, c)} />
        ))}
      </FilterBlock>
      <FilterBlock title="Brand">
        {BRANDS.map((b) => <Check key={b} label={b} checked={brands.includes(b)} onChange={() => toggle(brands, setBrands, b)} />)}
      </FilterBlock>
      <FilterBlock title="Colour">
        <div className="flex flex-wrap gap-2.5">
          {COLORS.map((c) => (
            <button key={c.name} title={c.name} onClick={() => toggle(cols, setCols, c.name)}
              className={cn("h-8 w-8 rounded-full border transition-all", cols.includes(c.name) ? "ring-2 ring-gold ring-offset-2 dark:ring-offset-neutral-950" : "border-neutral-300")}
              style={{ backgroundColor: c.hex }} />
          ))}
        </div>
      </FilterBlock>
      <FilterBlock title="Size">
        <div className="flex flex-wrap gap-2">
          {SIZES.map((s) => (
            <button key={s} onClick={() => toggle(sizes, setSizes, s)}
              className={cn("min-w-10 rounded-full border px-3 py-1.5 text-xs transition-all", sizes.includes(s) ? "border-gold bg-gold text-ink" : "border-neutral-300 hover:border-gold dark:border-neutral-700")}>
              {s}
            </button>
          ))}
        </div>
      </FilterBlock>
      <FilterBlock title={`Max Price — $${maxPrice}`}>
        <input type="range" min={100} max={1600} step={50} value={maxPrice}
          onChange={(e) => { setMaxPrice(Number(e.target.value)); setPage(1); }}
          className="w-full accent-[#c9a84c]" />
      </FilterBlock>
      <button onClick={clearAll} className="text-xs uppercase tracking-[0.2em] text-gold link-underline">Clear all filters</button>
    </div>
  );

  return (
    <div>
      {/* Header */}
      <div className="relative overflow-hidden">
        <img src={collectionMeta?.image ?? collections[0].image} alt="" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-ink/60" />
        <div className="relative mx-auto max-w-[1400px] px-6 py-20 text-center text-white md:px-8 md:py-28">
          <p className="text-[11px] uppercase tracking-[0.3em] text-gold">{fixedCollection ? collectionMeta?.tagline : "The Full Edit"}</p>
          <h1 className="mt-3 font-display text-5xl md:text-6xl">{fixedCollection ? `${fixedCollection}'s Collection` : "Shop All"}</h1>
          <p className="mt-3 text-sm text-neutral-300">{filtered.length} pieces</p>
        </div>
      </div>

      <div className="mx-auto max-w-[1400px] px-6 py-12 md:px-8">
        <div className="grid gap-10 lg:grid-cols-[260px_1fr]">
          <aside className="hidden lg:block"><div className="sticky top-28">{Filters}</div></aside>

          <div>
            <div className="mb-8 flex items-center justify-between gap-4">
              <button onClick={() => setDrawer(true)} className="flex items-center gap-2 rounded-full border border-ink/20 px-5 py-2.5 text-xs uppercase tracking-[0.15em] lg:hidden dark:border-white/20">
                <Icon.Menu className="h-4 w-4" /> Filters
              </button>
              <span className="hidden text-sm text-neutral-500 lg:block">Showing {shown.length} of {filtered.length}</span>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase tracking-[0.15em] text-neutral-400">Sort</span>
                <select value={sort} onChange={(e) => setSort(e.target.value)}
                  className="rounded-full border border-ink/20 bg-transparent px-4 py-2.5 text-sm focus:border-gold focus:outline-none dark:border-white/20">
                  <option value="featured">Featured</option>
                  <option value="new">Newest</option>
                  <option value="low">Price: Low to High</option>
                  <option value="high">Price: High to Low</option>
                  <option value="rating">Top Rated</option>
                </select>
              </div>
            </div>

            {shown.length === 0 ? (
              <p className="py-20 text-center text-neutral-400">No products match your filters.</p>
            ) : (
              <div className="grid grid-cols-2 gap-x-4 gap-y-8 lg:grid-cols-3">
                {shown.map((p, i) => (
                  <Reveal key={p.id} delay={i * 60}><ProductCard product={p} onQuickView={setQuickView} /></Reveal>
                ))}
              </div>
            )}

            {pages > 1 && (
              <div className="mt-14 flex items-center justify-center gap-2">
                {Array.from({ length: pages }).map((_, i) => (
                  <button key={i} onClick={() => { setPage(i + 1); window.scrollTo({ top: 300, behavior: "smooth" }); }}
                    className={cn("h-10 w-10 rounded-full text-sm transition-all", page === i + 1 ? "bg-gold text-ink" : "border border-ink/15 hover:border-gold dark:border-white/15")}>
                    {i + 1}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile filter drawer */}
      <div className={cn("fixed inset-0 z-[80] lg:hidden", drawer ? "" : "pointer-events-none")}>
        <div className={cn("absolute inset-0 bg-ink/50 transition-opacity", drawer ? "opacity-100" : "opacity-0")} onClick={() => setDrawer(false)} />
        <div className={cn("absolute right-0 top-0 h-full w-80 max-w-[85%] overflow-y-auto bg-white p-6 transition-transform duration-500 dark:bg-neutral-950", drawer ? "translate-x-0" : "translate-x-full")}>
          <div className="mb-6 flex items-center justify-between">
            <h3 className="font-display text-xl">Filters</h3>
            <button onClick={() => setDrawer(false)}><Icon.Close className="h-6 w-6" /></button>
          </div>
          {Filters}
        </div>
      </div>
    </div>
  );
}

function FilterBlock({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h4 className="mb-3 text-[11px] font-semibold uppercase tracking-[0.2em] text-neutral-500">{title}</h4>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

function Check({ label, checked, onChange }: { label: string; checked: boolean; onChange: () => void }) {
  return (
    <button onClick={onChange} className="flex w-full items-center gap-3 text-left text-sm text-neutral-600 transition-colors hover:text-gold dark:text-neutral-300">
      <span className={cn("flex h-4 w-4 items-center justify-center rounded border transition-colors", checked ? "border-gold bg-gold text-ink" : "border-neutral-400")}>
        {checked && <Icon.Check className="h-3 w-3" strokeWidth={3} />}
      </span>
      {label}
    </button>
  );
}
